package com.NCTW;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;

public class MenuActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu);
	}
	
	public void startUser(View view){
		
		Intent inte = new Intent(MenuActivity.this, UserActivity.class);
		MenuActivity.this.startActivity(inte);
		
	}
	
public void startCalendar(View view){
		
		Intent inte = new Intent(MenuActivity.this, CalendarActivity.class);
		MenuActivity.this.startActivity(inte);
		
	}

public void startPigg(View view){
	
	Intent inte = new Intent(MenuActivity.this, PiggActivity.class);
	MenuActivity.this.startActivity(inte);
	
}

public void startWallet(View view){
	
	Intent inte = new Intent(MenuActivity.this, WalletActivity.class);
	MenuActivity.this.startActivity(inte);
	
}
}
