package com.NCTW;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	
	protected EditText  usLogin;
	private EditText usPass;
	protected TextView status;
	private ImageButton login;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		setContentView(R.layout.activity_main);
		usLogin = (EditText)this.findViewById(R.id.editText1);
		usPass = (EditText)this.findViewById(R.id.editText2);
		login = (ImageButton)this.findViewById(R.id.imageButton1);
		status = (TextView)this.findViewById(R.id.textView1);
		
	}
	
public void startMenu(){
	
	Intent intMenu = new Intent(MainActivity.this, MenuActivity.class);
	MainActivity.this.startActivity(intMenu);
	
}
	
public void startSigin(View view){
		

	Intent intSigin = new Intent(MainActivity.this, SiginActivity.class);
	MainActivity.this.startActivity(intSigin);
				
	}

public void login(View view){
	
	String userna = usLogin.getText().toString();

	String userpa = usPass.getText().toString();
	new LoginActivity(this,view).execute(userna,userpa);
			
}
}
