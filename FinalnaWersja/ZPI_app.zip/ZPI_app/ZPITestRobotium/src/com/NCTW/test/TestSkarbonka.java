package com.NCTW.test;

import com.NCTW.MainActivity;
import com.robotium.solo.*;
import android.test.ActivityInstrumentationTestCase2;


public class TestSkarbonka extends ActivityInstrumentationTestCase2<MainActivity> {
  	private Solo solo;
  	
  	public TestSkarbonka() {
		super(MainActivity.class);
  	}

  	public void setUp() throws Exception {
        super.setUp();
		solo = new Solo(getInstrumentation());
		getActivity();
  	}
  
   	@Override
   	public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        super.tearDown();
  	}
  
	public void testRun() {
		// Wait for activity: 'com.NCTW.MainActivity'
		solo.waitForActivity(com.NCTW.MainActivity.class, 2000);
		// Click on Empty Text View
		solo.clickOnView(solo.getView(com.NCTW.R.id.editTextDP));
		// Enter the text: 'test'
		solo.clearEditText((android.widget.EditText) solo.getView(com.NCTW.R.id.editTextDP));
		solo.enterText((android.widget.EditText) solo.getView(com.NCTW.R.id.editTextDP), "test");
		// Click on Empty Text View
		solo.clickOnView(solo.getView(com.NCTW.R.id.editText2DK));
		// Enter the text: 'test'
		solo.clearEditText((android.widget.EditText) solo.getView(com.NCTW.R.id.editText2DK));
		solo.enterText((android.widget.EditText) solo.getView(com.NCTW.R.id.editText2DK), "test");
		// Click on ImageView
		solo.clickOnView(solo.getView(com.NCTW.R.id.imageButton1));
		// Wait for activity: 'com.NCTW.MenuActivity'
		assertTrue("com.NCTW.MenuActivity is not found!", solo.waitForActivity(com.NCTW.MenuActivity.class));
		// Click on ImageView
		solo.clickOnView(solo.getView(com.NCTW.R.id.imageButtonPigg));
		// Wait for activity: 'com.NCTW.PiggActivity'
		assertTrue("com.NCTW.PiggActivity is not found!", solo.waitForActivity(com.NCTW.PiggActivity.class));
		// Set default small timeout to 12341 milliseconds
		Timeout.setSmallTimeout(12341);
		// Click on cay swiat
		solo.sleep(5000);
		solo.clickOnView(solo.getView(com.NCTW.R.id.spinnerWybierzSwinke));
		// Click on yyyyy: 
		solo.clickOnView(solo.getView(android.R.id.text1, 1));
		// Click on Empty Text View
		solo.clickOnView(solo.getView(com.NCTW.R.id.editSumaDoSkarbonki));
		// Enter the text: '5'
		solo.clearEditText((android.widget.EditText) solo.getView(com.NCTW.R.id.editSumaDoSkarbonki));
		solo.enterText((android.widget.EditText) solo.getView(com.NCTW.R.id.editSumaDoSkarbonki), "5");
		// Click on Nakarm Świnkę Skarbonkę
		solo.clickOnView(solo.getView(com.NCTW.R.id.bNakarm));
	}
}
