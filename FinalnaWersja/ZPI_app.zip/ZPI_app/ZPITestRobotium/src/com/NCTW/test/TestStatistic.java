package com.NCTW.test;

import com.NCTW.MainActivity;
import com.robotium.solo.*;
import android.test.ActivityInstrumentationTestCase2;


public class TestStatistic extends ActivityInstrumentationTestCase2<MainActivity> {
  	private Solo solo;
  	
  	public TestStatistic() {
		super(MainActivity.class);
  	}

  	public void setUp() throws Exception {
        super.setUp();
		solo = new Solo(getInstrumentation());
		getActivity();
  	}
  
   	@Override
   	public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        super.tearDown();
  	}
  
	public void testRun() {
		// Wait for activity: 'com.NCTW.MainActivity'
		solo.waitForActivity(com.NCTW.MainActivity.class, 2000);
		// Click on Empty Text View
		solo.clickOnView(solo.getView(com.NCTW.R.id.editTextDP));
		// Enter the text: 'test'
		solo.clearEditText((android.widget.EditText) solo.getView(com.NCTW.R.id.editTextDP));
		solo.enterText((android.widget.EditText) solo.getView(com.NCTW.R.id.editTextDP), "test");
		// Click on Empty Text View
		solo.clickOnView(solo.getView(com.NCTW.R.id.editText2DK));
		// Enter the text: 'test'
		solo.clearEditText((android.widget.EditText) solo.getView(com.NCTW.R.id.editText2DK));
		solo.enterText((android.widget.EditText) solo.getView(com.NCTW.R.id.editText2DK), "test");
		// Click on ImageView
		solo.clickOnView(solo.getView(com.NCTW.R.id.imageButton1));
		// Wait for activity: 'com.NCTW.MenuActivity'
		assertTrue("com.NCTW.MenuActivity is not found!", solo.waitForActivity(com.NCTW.MenuActivity.class));
		// Click on ImageView
		solo.clickOnView(solo.getView(com.NCTW.R.id.imageButtonWallet));
		// Wait for activity: 'com.NCTW.WalletActivity'
		assertTrue("com.NCTW.WalletActivity is not found!", solo.waitForActivity(com.NCTW.WalletActivity.class));
		// Click on ImageView
		solo.clickOnView(solo.getView(com.NCTW.R.id.imageView1));
		// Wait for activity: 'com.NCTW.WybStatActivity'
		assertTrue("com.NCTW.WybStatActivity is not found!", solo.waitForActivity(com.NCTW.WybStatActivity.class));
		// Click on Wydatek
		solo.clickOnView(solo.getView(com.NCTW.R.id.buttonWyd));
		// Wait for activity: 'com.NCTW.StatisticActivity'
		assertTrue("com.NCTW.StatisticActivity is not found!", solo.waitForActivity(com.NCTW.StatisticActivity.class));
		// Click on 1999-10-23
		solo.sleep(5000);
		solo.clickOnView(solo.getView(com.NCTW.R.id.spinner3));
		// Click on 2014-06-11
		solo.clickOnView(solo.getView(android.R.id.text1, 6));
		// Click on Generuj
		solo.clickOnView(solo.getView(com.NCTW.R.id.buttonWys));
		// Click on Wyswietl
		solo.sleep(5000);
		solo.clickOnView(solo.getView(com.NCTW.R.id.buttonWyd));
		// Press menu back key
		solo.sleep(5000);
		solo.goBack();
		// Press menu back key
		solo.goBack();
	}
}
