package com.NCTW.test;

import com.NCTW.MainActivity;
import com.robotium.solo.*;

import android.test.ActivityInstrumentationTestCase2;


public class TestAdd extends ActivityInstrumentationTestCase2<MainActivity> {
  	private Solo solo;
  	
  	public TestAdd() {
		super(MainActivity.class);
  	}

  	public void setUp() throws Exception {
        super.setUp();
		solo = new Solo(getInstrumentation());
		getActivity();
  	}
  
   	@Override
   	public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        super.tearDown();
  	}
  
	public void testRun() {
		// Wait for activity: 'com.NCTW.MainActivity'
		solo.waitForActivity(com.NCTW.MainActivity.class, 2000);
		// Click on Empty Text View
		solo.clickOnView(solo.getView(com.NCTW.R.id.editTextDP));
		// Enter the text: 'test'
		solo.clearEditText((android.widget.EditText) solo.getView(com.NCTW.R.id.editTextDP));
		solo.enterText((android.widget.EditText) solo.getView(com.NCTW.R.id.editTextDP), "test");
		// Click on Empty Text View
		solo.clickOnView(solo.getView(com.NCTW.R.id.editText2DK));
		// Enter the text: 'test'
		solo.clearEditText((android.widget.EditText) solo.getView(com.NCTW.R.id.editText2DK));
		solo.enterText((android.widget.EditText) solo.getView(com.NCTW.R.id.editText2DK), "test");
		// Click on ImageView
		solo.clickOnView(solo.getView(com.NCTW.R.id.imageButton1));
		// Wait for activity: 'com.NCTW.MenuActivity'
		assertTrue("com.NCTW.MenuActivity is not found!", solo.waitForActivity(com.NCTW.MenuActivity.class));
		// Click on ImageView
		solo.clickOnView(solo.getView(com.NCTW.R.id.imageButtonWallet));
		// Wait for activity: 'com.NCTW.WalletActivity'
		assertTrue("com.NCTW.WalletActivity is not found!", solo.waitForActivity(com.NCTW.WalletActivity.class));
		// Click on ImageView
		solo.clickOnView(solo.getView(com.NCTW.R.id.imageView2));
		// Wait for activity: 'com.NCTW.WalletWydatki'
		assertTrue("com.NCTW.WalletWydatki is not found!", solo.waitForActivity(com.NCTW.WalletWydatki.class));
		// Click on Empty Text View
		solo.sleep(10000);
		solo.clickOnView(solo.getView(com.NCTW.R.id.nazwa));
		// Enter the text: '50'
		solo.clearEditText((android.widget.EditText) solo.getView(com.NCTW.R.id.nazwa));
		solo.enterText((android.widget.EditText) solo.getView(com.NCTW.R.id.nazwa), "50");
		// Click on Empty Text View
		solo.clickOnView(solo.getView(com.NCTW.R.id.editText1));
		// Enter the text: 'robotium'
		solo.clearEditText((android.widget.EditText) solo.getView(com.NCTW.R.id.editText1));
		solo.enterText((android.widget.EditText) solo.getView(com.NCTW.R.id.editText1), "robotium");
		// Click on Mieszkanie
		solo.clickOnView(solo.getView(com.NCTW.R.id.spinner1));
		// Click on Inne opłaty
		solo.clickOnView(solo.getView(android.R.id.text1, 3));
		// Click on Dolar
		solo.clickOnView(solo.getView(com.NCTW.R.id.spinner2));
		// Click on Euro:
		solo.clickOnView(solo.getView(android.R.id.text1, 2));
		// Click on Gotówka
		solo.clickOnView(solo.getView(com.NCTW.R.id.spinner3));
		// Click on Przelew
		solo.clickOnView(solo.getView(android.R.id.text1, 4));
		// Click on Data
		solo.clickOnView(solo.getView(com.NCTW.R.id.ustawDate));
		// Wait for dialog
		solo.waitForDialogToOpen(5000);
		// Enter the text: 'mar'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 1));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 1), "mar");
		// Enter the text: '20'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input"));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input"), "20");
		// Enter the text: 'mar'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 1));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 1), "mar");
		// Enter the text: '19'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input"));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input"), "19");
		// Enter the text: 'mar'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 1));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 1), "mar");
		// Enter the text: '18'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input"));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input"), "18");
		// Enter the text: 'mar'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 1));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 1), "mar");
		// Enter the text: '17'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input"));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input"), "17");
		// Enter the text: 'mar'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 1));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 1), "mar");
		// Enter the text: '2013'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 2));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 2), "2013");
		// Enter the text: 'mar'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 1));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 1), "mar");
		// Enter the text: '2012'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 2));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 2), "2012");
		// Enter the text: 'mar'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 1));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 1), "mar");
		// Enter the text: '2011'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 2));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 2), "2011");
		// Enter the text: 'mar'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 1));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 1), "mar");
		// Enter the text: '2010'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 2));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 2), "2010");
		// Enter the text: 'mar'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 1));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 1), "mar");
		// Enter the text: '2009'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 2));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 2), "2009");
		// Enter the text: 'mar'
		solo.clearEditText((android.widget.EditText) solo.getView("numberpicker_input", 1));
		solo.enterText((android.widget.EditText) solo.getView("numberpicker_input", 1), "mar");
		// Click on Gotowe
		solo.clickOnView(solo.getView(android.R.id.button1));
		// Click on Dodaj do wydatkow
		solo.clickOnView(solo.getView(com.NCTW.R.id.dodajwydatek));
		// Press menu back key
		solo.goBack();
	}
}
