package com.NCTW.test;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.test.InstrumentationTestCase;
import android.widget.EditText;
import android.widget.ImageButton;

import com.NCTW.KontoPieniadze;
import com.NCTW.MainActivity;
import com.NCTW.MenuActivity;
import com.NCTW.R;
import com.NCTW.User;
import com.NCTW.UserActivity;
import com.robotium.solo.Solo;

public class TestMainToUser extends InstrumentationTestCase {
	
	private Solo solo;
	EditText et1,et2;
	ImageButton ib1,ib2;
	User user;
	
public void testMainTOUser(){
	//Start Main 
	Instrumentation instrumentation = getInstrumentation();
	Instrumentation.ActivityMonitor monitor = instrumentation.addMonitor(MainActivity.class.getName(), null, false);
	Intent intent = new Intent(Intent.ACTION_MAIN);
	intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	intent.setClassName(instrumentation.getTargetContext(), MainActivity.class.getName());
    instrumentation.startActivitySync(intent);
    Activity currentActivity = getInstrumentation().waitForMonitorWithTimeout(monitor, 5000);
    solo = new Solo(instrumentation, currentActivity);
    et1 = (EditText) currentActivity.findViewById(R.id.editTextDP);
    et2 = (EditText) currentActivity.findViewById(R.id.editText2DK);
    ib1 = (ImageButton) currentActivity.findViewById(R.id.imageButton1);
    user = new User();
    user.setLogin("test");
    user.setPassword("test");
    user.kontoPien = new KontoPieniadze();
    user.kontoPien.setStanKonta(300);
    user.kontoPien.setSuma_przychody(600);
    user.kontoPien.setSuma_wydatki(300);
    
    solo.clearEditText(et1);
    solo.clearEditText(et2);
    solo.enterText(et1, "test");
    solo.enterText(et2, "test");
    
   
    Intent addEvent = new Intent();
    addEvent.setClassName("com.NCTW", "com.NCTW.MenuActivity");
    addEvent.putExtra("user_data", user);
    
    
    instrumentation.removeMonitor(monitor);
    instrumentation = getInstrumentation();
	monitor = instrumentation.addMonitor(MenuActivity.class.getName(), null, false);
	 solo.clickOnView(ib1);
	currentActivity = getInstrumentation().waitForMonitorWithTimeout(monitor, 10000);
	currentActivity.setIntent(addEvent);
	
	ib2 = (ImageButton) currentActivity.findViewById(R.id.imageButtonUser);
	
	instrumentation.removeMonitor(monitor);
    instrumentation = getInstrumentation();
	monitor = instrumentation.addMonitor(UserActivity.class.getName(), null, false);
	solo.clickOnView(ib2);
	currentActivity = getInstrumentation().waitForMonitorWithTimeout(monitor, 10000);
	currentActivity.setIntent(addEvent);
	
	assertTrue(solo.searchText("Witaj"));
	

	
}

}
