package com.NCTW;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class WalletWydatki extends Activity implements OnItemSelectedListener {

	Kategoria kategoria;
	View view;
	User user;
	TextView Output,tv;
	EditText ednazwa, zaco;
	Spinner s1,s2,s3;


	private int year;
	private int month;
	private int day;
	Button dodajWydatek, dodajPrzychody, ustawD;
	List<String> listaKategoria;
	List<String> listaWaluta;
	List<String> listaFormaPlatnosci;
	JSONParser jsonParser=new JSONParser();
	private static final String Tag_sukces="success";
	static final int DATE_PICKER_ID = 1111; 
	
	private String URL_Kategoria="http://student.agh.edu.pl/~jpelczar/pobierzKategorie.php";
	private String URL_Waluta="http://student.agh.edu.pl/~jpelczar/pobierzWalute.php";
	private String URL_Forma="http://student.agh.edu.pl/~jpelczar/pobierzForme.php";
	private String URL_DodajWydatek="http://student.agh.edu.pl/~jpelczar/dodanieWydatku.php";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_wallet_wydatki);
		ustawD=(Button) this.findViewById(R.id.ustawDate);
		Output = (TextView) findViewById(R.id.Output);
		dodajWydatek=(Button) this.findViewById(R.id.dodajwydatek);
		dodajPrzychody=(Button) this.findViewById(R.id.dodajprzychody);
		s1=(Spinner) this.findViewById(R.id.spinner1);
		s2=(Spinner) this.findViewById(R.id.spinner2);
		s3=(Spinner) this.findViewById(R.id.spinner3);
		ednazwa=(EditText) this.findViewById(R.id.nazwa);
		zaco=(EditText) this.findViewById(R.id.editText1);
		tv = (TextView) this.findViewById(R.id.textView1);
	
		user = new User();
		Bundle extras = getIntent().getExtras();
		user = (User)extras.get("user_data");
		
	    listaKategoria = new ArrayList<String>();
	    listaWaluta = new ArrayList<String>();
	    listaFormaPlatnosci = new ArrayList<String>();
	
		//s1.setOnItemSelectedListener(this);
		//s2.setOnItemSelectedListener(this);
		//s3.setOnItemSelectedListener(this);
		

	
		dodajWydatek.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
			//if(zaco.getText().toString().trim().length() >0 && ednazwa.getText().toString().trim().length()>0){
				//String NewZaco=zaco.getText().toString();
				//String Newednazwa=ednazwa.getText().toString();
				new DodanieWydatku().execute();
			//}
		
				
			}
			
		});
		
		dodajPrzychody.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
		
				new DodaniePrzychodu().execute(); //analogicznie jak dla wydatkow tylko do tabelki przychody
			//}
		
				
			}
			
		});
		
	
		
	//	new GetKategoria().execute();
	//	new GetWaluta().execute();
	//	new GetFormaPlatnosci().execute();
		new GetKategoriaKuba().execute();
		new GetWalutaKuba().execute();
		new GetFormaKuba().execute();
		
		//--------------data
		 // Get current date by calender
        
        final Calendar c = Calendar.getInstance();
        year  = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);
        day   = c.get(Calendar.DAY_OF_MONTH);
 
        // Show current date
         
        Output.setText(new StringBuilder()
                // Month is 0 based, just add 1
                .append(year).append("-").append(month+1).append("-")
                .append(day).append(" "));
  
        // Button listener to show date picker dialog
         
        ustawD.setOnClickListener(new OnClickListener() {
        	 
            @Override
            public void onClick(View v) {
                 
                // On button click show datepicker dialog
                showDialog(DATE_PICKER_ID);
 
            }
 
        });
		
	}


	 @Override
	    protected Dialog onCreateDialog(int id) {
	        switch (id) {
	        case DATE_PICKER_ID:
	             
	            // open datepicker dialog.
	            // set date picker for current date
	            // add pickerListener listner to date picker
	            return new DatePickerDialog(this, pickerListener, year, month,day);
	        }
	        return null;
	    }
	 
	    private DatePickerDialog.OnDateSetListener pickerListener = new DatePickerDialog.OnDateSetListener() {
	 
	        // when dialog box is closed, below method will be called.
	        @Override
	        public void onDateSet(DatePicker view, int selectedYear,
	                int selectedMonth, int selectedDay) {
	             
	            year  = selectedYear;
	            month = selectedMonth;
	            day   = selectedDay;
	 
	            // Show selected date
	            Output.setText(new StringBuilder().append(year)
	                    .append("-").append(month+1).append("-").append(day)
	                    .append(" "));
	     
	           }
	        };
	
	   /**
     * Adding spinner data
     * */
	        private class GetKategoriaKuba  extends AsyncTask<Void, Void,String>{

		@Override
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			try{
			String link="http://student.agh.edu.pl/~jpelczar/PobranieKategoriiKuba.php"; //tu link do strony która wywola kwerende, mozemy przechwycic wszystko co na stronie bedzie echo 
            String data  = URLEncoder.encode("co", "UTF-8") 
            + "=" + URLEncoder.encode("kategoria", "UTF-8");

            URL url = new URL(link);
            URLConnection conn = url.openConnection(); 
            conn.setDoOutput(true); 
            OutputStreamWriter wr = new OutputStreamWriter
            (conn.getOutputStream()); 
            wr.write( data ); 
            wr.flush(); 
            BufferedReader reader = new BufferedReader
            (new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null; 
            // Read Server Response
            while((line = reader.readLine()) != null)
            {
               sb.append(line); 
             
            
            }
			

            return sb.toString();
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return null;


		}
	        	
	        
	        
	        protected void onPostExecute(String result) {
	        	String[] tmp = new String[2]; //dzielenie wynikow
	    		tmp = result.split("\\:",2);
	    		
	    		
	    		int rozmiar = Integer.parseInt(tmp[0]);
	    		String[] rekordy = new String[rozmiar];
	    		//sAc.tv.append("r: " + rozmiar + " " );
	    		
	    		rekordy = tmp[1].split("\\:",rozmiar);
	    		for (int i = 0; i < rozmiar;i++){
	    			listaKategoria.add(rekordy[i]);
	    		}
	    		populateSpinner();
	    		
	        }
	        
	        }
	        ///////////////////////////////////////
	        
	        private class GetWalutaKuba  extends AsyncTask<Void, Void,String>{

	    		@Override
	    		protected String doInBackground(Void... params) {
	    			// TODO Auto-generated method stub
	    			try{
	    			String link="http://student.agh.edu.pl/~jpelczar/PobranieKategoriiKuba.php"; //tu link do strony która wywola kwerende, mozemy przechwycic wszystko co na stronie bedzie echo 
	                String data  = URLEncoder.encode("co", "UTF-8") 
	                + "=" + URLEncoder.encode("waluta", "UTF-8");

	                URL url = new URL(link);
	                URLConnection conn = url.openConnection(); 
	                conn.setDoOutput(true); 
	                OutputStreamWriter wr = new OutputStreamWriter
	                (conn.getOutputStream()); 
	                wr.write( data ); 
	                wr.flush(); 
	                BufferedReader reader = new BufferedReader
	                (new InputStreamReader(conn.getInputStream()));
	                StringBuilder sb = new StringBuilder();
	                String line = null; 
	                // Read Server Response
	                while((line = reader.readLine()) != null)
	                {
	                   sb.append(line); 
	                 
	                
	                }
	    			

	                return sb.toString();
	    			}
	    			catch(Exception e){
	    				e.printStackTrace();
	    			}
	    			return null;


	    		}
	    	        	
	    	        
	    	        
	    	        protected void onPostExecute(String result) {
	    	        	String[] tmp = new String[2]; //dzielenie wynikow
	    	    		tmp = result.split("\\:",2);
	    	    		
	    	    		//tmp[0] = tmp[0].substring(1, tmp[0].length());
	    	    		
	    	    		int rozmiar = Integer.parseInt(tmp[0]);
	    	    		String[] rekordy = new String[rozmiar];
	    	    		//sAc.tv.append("r: " + rozmiar + " " );
	    	    		
	    	    		rekordy = tmp[1].split("\\:",rozmiar);
	    	    		for (int i = 0; i < rozmiar;i++){
	    	    			listaWaluta.add(rekordy[i]);
	    	    		}
	    	    		populateSpinnerWaluta();
	    	        }
	    	        
	    	        }
	    	        ///////////////////////////////////////
	        
	        private class GetFormaKuba  extends AsyncTask<Void, Void,String>{

	    		@Override
	    		protected String doInBackground(Void... params) {
	    			// TODO Auto-generated method stub
	    			try{
	    			String link="http://student.agh.edu.pl/~jpelczar/PobranieKategoriiKuba.php"; //tu link do strony która wywola kwerende, mozemy przechwycic wszystko co na stronie bedzie echo 
	                String data  = URLEncoder.encode("co", "UTF-8") 
	                + "=" + URLEncoder.encode("forma", "UTF-8");

	                URL url = new URL(link);
	                URLConnection conn = url.openConnection(); 
	                conn.setDoOutput(true); 
	                OutputStreamWriter wr = new OutputStreamWriter
	                (conn.getOutputStream()); 
	                wr.write( data ); 
	                wr.flush(); 
	                BufferedReader reader = new BufferedReader
	                (new InputStreamReader(conn.getInputStream()));
	                StringBuilder sb = new StringBuilder();
	                String line = null; 
	                // Read Server Response
	                while((line = reader.readLine()) != null)
	                {
	                   sb.append(line); 
	                 
	                
	                }
	    			

	                return sb.toString();
	    			}
	    			catch(Exception e){
	    				e.printStackTrace();
	    			}
	    			return null;


	    		}
	    	        	
	    	        
	    	        
	    	        protected void onPostExecute(String result) {
	    	        	String[] tmp = new String[2]; //dzielenie wynikow
	    	    		tmp = result.split("\\:",2);
	    	    		
	    	    		//tmp[0] = tmp[0].substring(1, tmp[0].length());
	    	    		
	    	    		int rozmiar = Integer.parseInt(tmp[0]);
	    	    		String[] rekordy = new String[rozmiar];
	    	    		//sAc.tv.append("r: " + rozmiar + " " );
	    	    		
	    	    		rekordy = tmp[1].split("\\:",rozmiar);
	    	    		for (int i = 0; i < rozmiar;i++){
	    	    			listaFormaPlatnosci.add(rekordy[i]);
	    	    		}
	    	    		populateSpinnerForma();
	    	        }
	    	        
	    	        
	    	        }
	    	        ///////////////////////////////////////
	        private void populateSpinner() {
	            List<String> lables = new ArrayList<String>();
	             
	            //txtCategory.setText("");
	     
	            for (int i = 0; i < listaKategoria.size(); i++) {
	                lables.add(listaKategoria.get(i));
	            }
	     
	            // Creating adapter for spinner
	            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
	                    android.R.layout.simple_spinner_item, lables);
	            // Drop down layout style - list view with radio button
	            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	            // attaching data adapter to spinner
	            spinnerAdapter.notifyDataSetChanged();
	            s1.setAdapter(spinnerAdapter);
	        }
	        
	        
	        private void populateSpinnerWaluta() {
	            List<String> lables = new ArrayList<String>();
	             
	            //txtCategory.setText("");
	     
	            for (int i = 0; i < listaWaluta.size(); i++) {
	                lables.add(listaWaluta.get(i));
	            }
	     
	            // Creating adapter for spinner
	            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
	                    android.R.layout.simple_spinner_item, lables);
	            // Drop down layout style - list view with radio button
	            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	            // attaching data adapter to spinner
	            spinnerAdapter.notifyDataSetChanged();
	            s2.setAdapter(spinnerAdapter);
	        }
	        
	        private void populateSpinnerForma() {
	            List<String> lables = new ArrayList<String>();
	             
	            //txtCategory.setText("");
	     
	            for (int i = 0; i < listaFormaPlatnosci.size(); i++) {
	                lables.add(listaFormaPlatnosci.get(i));
	            }
	     
	            // Creating adapter for spinner
	            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
	                    android.R.layout.simple_spinner_item, lables);
	            // Drop down layout style - list view with radio button
	            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	            // attaching data adapter to spinner
	            spinnerAdapter.notifyDataSetChanged();
	            s3.setAdapter(spinnerAdapter);
	        }
	        
	        /*
    private void populateSpinner() {
        List<String> lables = new ArrayList<String>();
         
        //txtCategory.setText("");
 
        for (int i = 0; i < listaKategoria.size(); i++) {
            lables.add(listaKategoria.get(i).getNazwa());
        }
 
        // Creating adapter for spinner
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);
        // Drop down layout style - list view with radio button
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinnerAdapter.notifyDataSetChanged();
        s1.setAdapter(spinnerAdapter);
    }
    
    
    private void populateSpinnerWaluta() {
        List<String> lables = new ArrayList<String>();
         
        //txtCategory.setText("");
 
        for (int i = 0; i < listaWaluta.size(); i++) {
            lables.add(listaWaluta.get(i).getNazwaWaluty());
        }
 
        // Creating adapter for spinner
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);
        // Drop down layout style - list view with radio button
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinnerAdapter.notifyDataSetChanged();
        s2.setAdapter(spinnerAdapter);
    }
    
    private void populateSpinnerForma() {
        List<String> lables = new ArrayList<String>();
         
        //txtCategory.setText("");
 
        for (int i = 0; i < listaFormaPlatnosci.size(); i++) {
            lables.add(listaFormaPlatnosci.get(i).getNazwaFormy());
        }
 
        // Creating adapter for spinner
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);
        // Drop down layout style - list view with radio button
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinnerAdapter.notifyDataSetChanged();
        s3.setAdapter(spinnerAdapter);
    }
    
    

	private class GetKategoria extends AsyncTask<Void, Void, Void> {
		 
        protected void onPreExecute() {
          
        }
 
        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String json = jsonParser.makeServiceCall(URL_Kategoria, ServiceHandler.POST);
 
            Log.e("Response: ", "> " + json);
 
            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categories = jsonObj.getJSONArray("Kategoria");                       
 
                        for (int i = 0; i < categories.length(); i++) {
                            JSONObject catObj = (JSONObject) categories.get(i);
                            Kategoria cat = new Kategoria(catObj.getInt("idKategoria"), catObj.getString("Nazwa"));
                            listaKategoria.add(cat);
                            
                        }
                    }
 
                } catch (JSONException e) {
                    e.printStackTrace();
                }
 
            } else {
                Log.e("JSON Data", "Didn't receive any data from server!");
            }
 
            return null;
        }
 
        protected void onPostExecute(Void result) {
        	 super.onPostExecute(result);
        	 populateSpinner();
        	 tv.append("Kategorie ok");
        	 getWindow().getDecorView().findViewById(android.R.id.content).invalidate();
        	 
        }
 
    }

*/
	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {
        Toast.makeText(  getApplicationContext(),
                     parent.getItemAtPosition(position).toString() + " wybrałeś" ,
                Toast.LENGTH_LONG).show();
		
	}
	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub
		
	}

/*	
	private class GetWaluta extends AsyncTask<Void, Void, Void> {
		 
        protected void onPreExecute() {
          
        }
 
        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String json = jsonParser.makeServiceCall(URL_Waluta, ServiceHandler.POST);
 
            Log.e("Response: ", "> " + json);
 
            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categories = jsonObj.getJSONArray("Waluta");                       
 
                        for (int i = 0; i < categories.length(); i++) {
                            JSONObject catObj = (JSONObject) categories.get(i);
                            Waluta cat = new Waluta(catObj.getInt("idWaluta"), catObj.getString("Nazwa"));
                            listaWaluta.add(cat);
                           
                           
                        }
                    }
 
                } catch (JSONException e) {
                    e.printStackTrace();
                }
 
            } else {
                Log.e("JSON Data", "Didn't receive any data from server!");
            }
 
            return null;
        }
 
        protected void onPostExecute(Void result) {
        	 super.onPostExecute(result);
        	 populateSpinnerWaluta();
        	 tv.append("Waluta ok");
        	 getWindow().getDecorView().findViewById(android.R.id.content).invalidate();
        }
 
    }

	
	private class GetFormaPlatnosci extends AsyncTask<Void, Void, Void> {
		 
        protected void onPreExecute() {
          
        }
 
        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String json = jsonParser.makeServiceCall(URL_Forma, ServiceHandler.POST);
 
            Log.e("Response: ", "> " + json);
 
            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categories = jsonObj.getJSONArray("FormaPlatnosc");                       
 
                        for (int i = 0; i < categories.length(); i++) {
                            JSONObject catObj = (JSONObject) categories.get(i);
                            FormaPlatnosci cat = new FormaPlatnosci(catObj.getInt("idFormaPlatnosc"), catObj.getString("NazwaFormy"));
                            listaFormaPlatnosci.add(cat);
                            
                        }
                    }
 
                } catch (JSONException e) {
                    e.printStackTrace();
                }
 
            } else {
                Log.e("JSON Data", "Didn't receive any data from server!");
            }
 
            return null;
        }
 
        protected void onPostExecute(Void result) {
        	 super.onPostExecute(result);
        	 populateSpinnerForma();
        	 tv.append("?Forma ok");
        	 getWindow().getDecorView().findViewById(android.R.id.content).invalidate();
        }
 
    }

	
	//---dodanie do bazy calosci8*/
	
	private class DodanieWydatku  extends AsyncTask<String, String, String> {



		
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
         
        }

			
			@Override
			protected String doInBackground(String... params) {
			try{
				String nowyKoszt=ednazwa.getText().toString();
				String nowaNazwa=zaco.getText().toString();
				String nowaWaluta=Long.toString( s2.getItemIdAtPosition(s2.getSelectedItemPosition())+1);
				String nowaForma=Long.toString( s3.getItemIdAtPosition(s3.getSelectedItemPosition())+1);
				String nowaKategoria=Long.toString( s1.getItemIdAtPosition(s1.getSelectedItemPosition())+1);
				String nowyUzytkownik=user.getLogin();
				
				String nowaData=Output.getText().toString();


		        String link="http://student.agh.edu.pl/~jpelczar/dodanieWydatku.php";

	            String data  = URLEncoder.encode("koszt", "UTF-8") 
	            + "=" + URLEncoder.encode(nowyKoszt, "UTF-8");
	            data += "&" + URLEncoder.encode("waluta", "UTF-8") 
	            + "=" + URLEncoder.encode(nowaWaluta, "UTF-8");
	            data += "&" + URLEncoder.encode("formapl", "UTF-8") 
	             + "=" + URLEncoder.encode(nowaForma, "UTF-8");
	            data += "&" + URLEncoder.encode("kategoria", "UTF-8") 
	            + "=" + URLEncoder.encode(nowaKategoria, "UTF-8");
	            data += "&" + URLEncoder.encode("nazwa", "UTF-8") 
	    	    + "=" + URLEncoder.encode(nowaNazwa, "UTF-8");
	            data += "&" + URLEncoder.encode("uzytk", "UTF-8") 
	    	            + "=" + URLEncoder.encode(nowyUzytkownik, "UTF-8");
	            data += "&" + URLEncoder.encode("data", "UTF-8") 
	    	            + "=" + URLEncoder.encode(nowaData, "UTF-8");
	            URL url = new URL(link);
	            URLConnection conn = url.openConnection(); 
	            conn.setDoOutput(true); 
	            OutputStreamWriter wr = new OutputStreamWriter
	            (conn.getOutputStream()); 
	            wr.write( data ); 
	            wr.flush(); 

	            BufferedReader reader = new BufferedReader
	            (new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = null; 
	            // Read Server Response
	            while((line = reader.readLine()) != null)
	            {
	               sb.append(line); 
	               
	               
	            }

	            return sb.toString();
	         }catch(Exception e){
	            return new String("Exception: " + e.getMessage());
	         }

			}
	    

	    protected void onPostExecute(String result) {
	    		tv.setText(result + "Dodano");
	    	
	    		
	    	//	tv.append(Long.toString( s1.getItemIdAtPosition(s1.getSelectedItemPosition())));
	    	//	tv.append(Long.toString( s2.getItemIdAtPosition(s2.getSelectedItemPosition())));
	    	//	tv.append(Long.toString( s3.getItemIdAtPosition(s3.getSelectedItemPosition())));
	    }

			
		

		
	}
public class DodaniePrzychodu extends AsyncTask<String, String, String> {

		
	    @Override
	    protected void onPreExecute() {
	        super.onPreExecute();
	     
	    }

			
			@Override
			protected String doInBackground(String... params) {
			try{
				String nowyKoszt=ednazwa.getText().toString();
				String nowaNazwa=zaco.getText().toString();
				String nowaWaluta=Long.toString( s2.getItemIdAtPosition(s2.getSelectedItemPosition())+1);
				
				String nowaKategoria=Long.toString( s1.getItemIdAtPosition(s1.getSelectedItemPosition())+1);
				String nowyUzytkownik=user.getLogin();
				
				String nowaData=Output.getText().toString();


		        String link="http://student.agh.edu.pl/~jpelczar/dodajPrzychod.php";

	            String data  = URLEncoder.encode("koszt", "UTF-8") 
	            + "=" + URLEncoder.encode(nowyKoszt, "UTF-8");
	            data += "&" + URLEncoder.encode("waluta", "UTF-8") 
	            + "=" + URLEncoder.encode(nowaWaluta, "UTF-8");
	            data += "&" + URLEncoder.encode("kategoria", "UTF-8") 
	            + "=" + URLEncoder.encode(nowaKategoria, "UTF-8");
	            data += "&" + URLEncoder.encode("nazwa", "UTF-8") 
	    	    + "=" + URLEncoder.encode(nowaNazwa, "UTF-8");
	            data += "&" + URLEncoder.encode("uzytk", "UTF-8") 
	    	            + "=" + URLEncoder.encode(nowyUzytkownik, "UTF-8");
	            data += "&" + URLEncoder.encode("data", "UTF-8") 
	    	            + "=" + URLEncoder.encode(nowaData, "UTF-8");
	            URL url = new URL(link);
	            URLConnection conn = url.openConnection(); 
	            conn.setDoOutput(true); 
	            OutputStreamWriter wr = new OutputStreamWriter
	            (conn.getOutputStream()); 
	            wr.write( data ); 
	            wr.flush(); 

	            BufferedReader reader = new BufferedReader
	            (new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = null; 
	            // Read Server Response
	            while((line = reader.readLine()) != null)
	            {
	               sb.append(line); 
	               
	               
	            }

	            return sb.toString();
	         }catch(Exception e){
	            return new String("Exception: " + e.getMessage());
	         }

			}
	    

	    protected void onPostExecute(String result) {
	    		tv.setText(result);
	    	
	    }
}
	
}
