package com.NCTW;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;



import android.content.Context;
import android.os.AsyncTask;
import android.view.View;

public class Wyswietl extends AsyncTask<User,Void,String>{ // tu pierwsze to user bo takei cos przekazujemy w doInBeckground
	
	private String co;
	int cooo;
	Date dPocz, dKon;

	



	public static String res;
	public StatisticActivity sAc;
	float[] koszt;

	public Wyswietl(Context context,View view1,String c,Date dp, Date dk, int g) { //konstruktor 
		sAc = (StatisticActivity) context;
		co = c;
		dPocz = dp;
		dKon = dk;
		cooo = g;
		
	}

	@Override
	protected void onPreExecute(){ //to co na poczatku przed wykonaniem sie stanie
		
		sAc.tv.setText("");
	   }

	@Override
	protected String doInBackground(User... params) { // te parametry w execute sa przekazywane tu, specyfikujemy tu tyop jaki przekazujemy, inne zmienne w sumie mozna tez przez konstruktor przekazac 
		// TODO Auto-generated method stub
		try{
			User user = (User)params[0]; // a tu je parsujemy do naszego typu i przypisujemy do naszej zmiennej			
			try{
				user.kontoPien.setData_pocztek(dPocz);
				user.kontoPien.setData_koniec(dKon); 
			}
			catch(Exception e){
				
			}
			String link="http://student.agh.edu.pl/~jpelczar/"+co; //tu link do strony która wywola kwerende, mozemy przechwycic wszystko co na stronie bedzie echo 
            String data  = URLEncoder.encode("username", "UTF-8") 
            + "=" + URLEncoder.encode(user.getLogin(), "UTF-8");
            URL url = new URL(link);
            URLConnection conn = url.openConnection(); 
            conn.setDoOutput(true); 
            OutputStreamWriter wr = new OutputStreamWriter
            (conn.getOutputStream()); 
            wr.write( data ); 
            wr.flush(); 
            BufferedReader reader = new BufferedReader
            (new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null; 
            // Read Server Response
            while((line = reader.readLine()) != null)
            {
               sb.append(line + " "); 
            
            }

            return sb.toString();
         }catch(Exception e){
            return new String("Exception: " + e.getMessage());
         }
	}


	@Override
	   protected void onPostExecute(String result){ 
		
		
		
		
		String[] tmp = new String[2]; //dzielenie wynikow
		tmp = result.split("\\:",2);
		tmp[0] = tmp[0].substring(1, tmp[0].length());
		int rozmiar = Integer.parseInt(tmp[0]);
		String[] rekordy = new String[rozmiar];
		
		rekordy = tmp[1].split("\\:",rozmiar);
		int ile = 0;
		if (cooo == 1) {ile = 7;}
		if (cooo == 0) {ile = 6;}
		
		

		rozmiar = rekordy.length;
		for(int i =0; i < rekordy.length; i++){
			rekordy[i].trim();
			
		}
		
		String[][] wynik = new String[rozmiar][7]; //tablioca na wyniki
		
		koszt = new float[rozmiar];
		int repeat = 0;
		
		for(int i =0; i < rekordy.length; i++){
			wynik[i] = rekordy[i].split("\\=",7);
			for (int j =0; j<7; j++){
				wynik[i][j].replaceAll("=","");
				wynik[i][j].trim();				
			}
			
				koszt[i] = Float.parseFloat(wynik[i][2]);

		}
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date pocz, kon;
		int iPocz=0, iKon=1;
		try {
			for (int i =0; i< rekordy.length; i++){
				if (df.parse(wynik[i][0]).equals(sAc.user.kontoPien.getData_pocztek())){ iPocz = i; }
				if (df.parse(wynik[i][0]).equals(sAc.user.kontoPien.getData_koniec())){ iKon = i;} 
			}
			

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		String[] labelsW = null,labelsP = null;
	if(ile == 7){
		labelsW = new String[ile];
		labelsW[0] = "\n Data: ";
		labelsW[1] = " Login: ";
		labelsW[2] = " Ile: ";
		labelsW[3] = "\n Kategoria: ";
		labelsW[4] = " Forma Platnosci: ";
		labelsW[5] = "\n Waluta: ";
		labelsW[6] = " Komentarz: ";}
	else{
		labelsP = new String[ile];
		labelsP[0] = "\n Data: ";
		labelsP[1] = " Login: ";
		labelsP[2] = " Ile: ";
		labelsP[3] = "\n Kategoria: ";
		labelsP[4] = " Waluta:  ";
		labelsP[5] = "\n Komentarz: ";
	}
		

		for (int i = iPocz; i <= iKon ; i++){
			for (int j = 0; j < ile; j++){
				
				if (ile == 6) sAc.tv.append(labelsP[j] + wynik[i][j]);
				if (ile == 7) sAc.tv.append(labelsW[j] + wynik[i][j]);
				
			}
			
			
		}
		
	
		
		

		
			
		
		
	}

	
	float max(float[] tab){
		float maxVal = tab[0];
		for (int i = 0; i< tab.length; i++){
			if (maxVal < tab[i]) maxVal = tab[i];
		}
		
		
		return maxVal;
	}
}
