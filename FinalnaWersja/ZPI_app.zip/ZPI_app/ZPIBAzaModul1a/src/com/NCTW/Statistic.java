package com.NCTW;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.jjoe64.graphview.*;
import com.jjoe64.graphview.GraphView.GraphViewData;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;

public class Statistic extends AsyncTask<User,Void,String>{ // tu pierwsze to user bo takei cos przekazujemy w doInBeckground
	
	private String co;
	Date dPocz, dKon;

	



	public static String res;
	public StatisticActivity sAc;
	float[] koszt;

	public Statistic(Context context,View view1,String c,Date dp, Date dk) { //konstruktor 
		sAc = (StatisticActivity) context;
		co = c;
		dPocz = dp;
		dKon = dk;
		
	}

	@Override
	protected void onPreExecute(){ //to co na poczatku przed wykonaniem sie stanie
		
	      
	   }

	@Override
	protected String doInBackground(User... params) { // te parametry w execute sa przekazywane tu, specyfikujemy tu tyop jaki przekazujemy, inne zmienne w sumie mozna tez przez konstruktor przekazac 
		// TODO Auto-generated method stub
		try{
			User user = (User)params[0]; // a tu je parsujemy do naszego typu i przypisujemy do naszej zmiennej			
			try{
				user.kontoPien.setData_pocztek(dPocz);
				user.kontoPien.setData_koniec(dKon); 
			}
			catch(Exception e){
				
			}
			String link="http://student.agh.edu.pl/~jpelczar/"+co; //tu link do strony która wywola kwerende, mozemy przechwycic wszystko co na stronie bedzie echo 
            String data  = URLEncoder.encode("username", "UTF-8") 
            + "=" + URLEncoder.encode(user.getLogin(), "UTF-8");
            URL url = new URL(link);
            URLConnection conn = url.openConnection(); 
            conn.setDoOutput(true); 
            OutputStreamWriter wr = new OutputStreamWriter
            (conn.getOutputStream()); 
            wr.write( data ); 
            wr.flush(); 
            BufferedReader reader = new BufferedReader
            (new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null; 
            // Read Server Response
            while((line = reader.readLine()) != null)
            {
               sb.append(line + " "); 
            
            }

            return sb.toString();
         }catch(Exception e){
            return new String("Exception: " + e.getMessage());
         }
	}


	@Override
	   protected void onPostExecute(String result){ 
		
		
		
		
		String[] tmp = new String[2]; //dzielenie wynikow
		tmp = result.split("\\:",2);
		tmp[0] = tmp[0].substring(1, tmp[0].length());
		//sAc.tv.append(tmp[0]);
		int rozmiar = Integer.parseInt(tmp[0]);
		String[] rekordy = new String[rozmiar];
		
		rekordy = tmp[1].split("\\:",rozmiar);
		
		

		rozmiar = rekordy.length;
		for(int i =0; i < rekordy.length; i++){
			rekordy[i].trim();
			
		}
		
		String[][] wynik = new String[rozmiar][7]; //tablioca na wyniki
		
		koszt = new float[rozmiar];
		int repeat = 0;
		
		for(int i =0; i < rekordy.length; i++){
			wynik[i] = rekordy[i].split("\\=",7);
			for (int j =0; j<7; j++){
				wynik[i][j].replaceAll("=","");
				wynik[i][j].trim();				
			}
			
			if ( i > 0 && wynik[i][0].equals(wynik[i-1][0])){
				repeat--;

				koszt[repeat] += Float.parseFloat(wynik[i][2]);  //koszty do floata
				repeat++;
			}
			else {
				
				koszt[repeat] = Float.parseFloat(wynik[i][2]);
				repeat++;
			}
			
			
			
		}
		
		
		
		float maxVal = max(koszt); 
		final String[][]w = wynik;
		
		int tmpDat = 0;
		String[] data = new String[repeat];
		int tmpData = 0;
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		
		
		for (int i = 0; i < rozmiar; i++){ // tablica z datami wplat do etykiet
	
			if (i > 0 && w[i][0].equals(w[i-1][0])){
				
			}
			else {
				data[tmpDat] = w[i][0];
				try {
					if (df.parse(data[tmpDat]).after(sAc.user.kontoPien.getData_pocztek()) && (df.parse(data[tmpDat]).before(sAc.user.kontoPien.getData_koniec())) ) {tmpData++; /*sAc.tv.append(" tmp Data: " + tmpData);*/}
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				tmpDat++;
			}
		}
		
		int iPocz = 0, iKon = tmpDat;
		
		for (int i = 0; i < tmpDat; i++){
			
			try {
			
			if (df.parse(data[i]).equals(sAc.user.kontoPien.getData_pocztek())){ iPocz = i; /*sAc.tv.append(" iPocz " + iPocz);*/}
			if (df.parse(data[i]).equals(sAc.user.kontoPien.getData_koniec())){ iKon = i; /*sAc.tv.append(" iKon " + iKon);*/} 
			
			
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		float[] kosztStat = new float[(iKon-iPocz)+1];
		int tmpKoszt = 0;
		for (int i = iPocz; i<= iKon; i++){
			kosztStat[tmpKoszt] = koszt[i]; 
			tmpKoszt++;
		}
		
		GraphViewData[] gp = new GraphViewData[tmpData+2]; //dane do wykresu tyle ile kosztow

		
		int tmpGVD = 0;
		for (int i =0; i <= tmpData+1; i++ ){
			if (kosztStat[i] != 0){
				gp[tmpGVD] = new GraphViewData (tmpGVD,kosztStat[i]);
				tmpGVD++;
			}
			else break;
		}
		
		sAc.exampleSeries = new GraphViewSeries(gp); // dane dodane do wykresu
		final int tmpRep = repeat;
		final String[] d = data;
		final int tmpiPocz = iPocz;
		final int tmpiKon = iKon;
				sAc.graphView.addSeries(sAc.exampleSeries);
				sAc.graphView.setScrollable(true);
				sAc.graphView.setViewPort(1, 2);
				sAc.graphView.setScalable(true);
				sAc.graphView.setCustomLabelFormatter(new CustomLabelFormatter(){ // edycja wtykiet na X
					
					@Override
					public String formatLabel(double value, boolean isValueX) {
						// TODO Auto-generated method stub
						if (isValueX){
								if (value>=1 && value<tmpRep) { if  ((int) value + tmpiPocz < tmpiKon) {return d[(int) value + tmpiPocz];} else { return d[tmpiKon];} }
								else return d[tmpiPocz];
							}	

					
						return null;
					}
				});
				//sAc.graphView.setHorizontalLabels(data);
				
				sAc.graphView.getGraphViewStyle().setTextSize(11);
				sAc.lay.addView(sAc.graphView);
				
		
		
	   }

	
	float max(float[] tab){
		float maxVal = tab[0];
		for (int i = 0; i< tab.length; i++){
			if (maxVal < tab[i]) maxVal = tab[i];
		}
		
		
		return maxVal;
	}
}
