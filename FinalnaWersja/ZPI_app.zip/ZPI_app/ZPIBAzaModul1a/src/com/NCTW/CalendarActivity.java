package com.NCTW;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.Date;
import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

public class CalendarActivity extends Activity {

	Button bDodajWydarzenie;
	Button bData;
	EditText tekstWydarzenia;
	TextView Output, tekstspr,wysw;
	int year;
	int month;
	int day;
	static final int DATE_PICKER_ID = 1111;
	User user;

	public void wys(View view){
		new WysWydarzenie().execute();
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_calendar);
		user = new User();
		Bundle extras = getIntent().getExtras();
		user = (User)extras.get("user_data");
		bDodajWydarzenie=(Button) this.findViewById(R.id.buttonWydarzenie);
		bData=(Button) this.findViewById(R.id.buttonData);
		tekstWydarzenia=(EditText) this.findViewById(R.id.wpiszWydarzenie);
		tekstspr=(TextView) this.findViewById(R.id.textDodany);
		wysw = (TextView) this.findViewById(R.id.textWys);
	
		Output=(TextView) this.findViewById(R.id.Output);
		
	
	bDodajWydarzenie.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
		new DodajWydarzenie().execute();
			
		}
	});
		

	//--------------data
	 // Get current date by calender
   
   final Calendar c = Calendar.getInstance();
   year  = c.get(Calendar.YEAR);
   month = c.get(Calendar.MONTH);
   day   = c.get(Calendar.DAY_OF_MONTH);

   // Show current date
    
 if (month+1<10){  Output.setText(new StringBuilder()
           // Month is 0 based, just add 1
           .append(year).append("-0").append(month+1).append("-")
           .append(day).append(" "));
 }
 else {
	 Output.setText(new StringBuilder()
     // Month is 0 based, just add 1
     .append(year).append("-").append(month+1).append("-")
     .append(day).append(" "));
	 
 }
   // Button listener to show date picker dialog
    
   bData.setOnClickListener(new OnClickListener() {
   	 
       @Override
       public void onClick(View v) {
            
           // On button click show datepicker dialog
           showDialog(DATE_PICKER_ID);

       }

   });
   
	}



@Override
   protected Dialog onCreateDialog(int id) {
       switch (id) {
       case DATE_PICKER_ID:
            
           // open datepicker dialog.
           // set date picker for current date
           // add pickerListener listner to date picker
           return new DatePickerDialog(this, pickerListener, year, month,day);
       }
       return null;
   }

   private DatePickerDialog.OnDateSetListener pickerListener = new DatePickerDialog.OnDateSetListener() {

       // when dialog box is closed, below method will be called.
       @Override
       public void onDateSet(DatePicker view, int selectedYear,
               int selectedMonth, int selectedDay) {
            
           year  = selectedYear;
           month = selectedMonth;
           day   = selectedDay;

           // Show selected date
           if (month+1<10){  Output.setText(new StringBuilder()
           // Month is 0 based, just add 1
           .append(year).append("-0").append(month+1).append("-")
           .append(day).append(" "));
 }
 else {
	 Output.setText(new StringBuilder()
     // Month is 0 based, just add 1
     .append(year).append("-").append(month+1).append("-")
     .append(day).append(" "));
	 
 }
    
          }
       };
//-------koniec odnosnie daty
       
       
       public class DodajWydarzenie extends AsyncTask<String, Void, String>{
    	   String nowaData;
			String nowyTekst;
    	   @Override
    		protected void onPreExecute(){ //to co na poczatku przed wykonaniem sie stanie
    			
    		      
    		   }

    		protected String doInBackground(String... params) { // te parametry w execute sa przekazywane tu, specyfikujemy tu tyop jaki przekazujemy, inne zmienne w sumie mozna tez przez konstruktor przekazac 
    			// TODO Auto-generated method stub
    			try{
    				
    				
    				nowaData=Output.getText().toString().trim();
    				nowyTekst=tekstWydarzenia.getText().toString();
    		        String link="http://student.agh.edu.pl/~jpelczar/dodajWydarzenie.php"; 
    	            String data  = URLEncoder.encode("tekst", "UTF-8") 
    	            + "=" + URLEncoder.encode(nowyTekst, "UTF-8");
    	            data += "&" + URLEncoder.encode("data", "UTF-8") 
    	            + "=" + URLEncoder.encode(nowaData, "UTF-8");
    	            data += "&" + URLEncoder.encode("user", "UTF-8") 
    	    	            + "=" + URLEncoder.encode(user.getLogin(), "UTF-8");
    	
    	            URL url = new URL(link);
    	            URLConnection conn = url.openConnection(); 
    	            conn.setDoOutput(true); 
    	            OutputStreamWriter wr = new OutputStreamWriter
    	            (conn.getOutputStream()); 
    	            wr.write( data ); 
    	            wr.flush(); 
    	            BufferedReader reader = new BufferedReader
    	            (new InputStreamReader(conn.getInputStream()));
    	            StringBuilder sb = new StringBuilder();
    	            String line = null; //do tad wszystko to mui byc, ponizej czytamy co dostalismy z serwera
    	            // Read Server Response
    	            while((line = reader.readLine()) != null)
    	            {
    	               sb.append(line); 
    	               
    	            }

    	            return sb.toString();
    	         }catch(Exception e){
    	            return new String("Exception: " + e.getMessage());
    	         }
    		}

    		protected void onPostExecute(String result){  // to co po wykonaniu sie zrobi

    			tekstspr.setText(result);

    				
    				}
    				}
       public class WysWydarzenie extends AsyncTask<String, Void, String>{
    	   String nowaData;
			String nowyTekst;
    	   @Override
    		protected void onPreExecute(){ //to co na poczatku przed wykonaniem sie stanie
    			
    		      
    		   }

    		protected String doInBackground(String... params) { // te parametry w execute sa przekazywane tu, specyfikujemy tu tyop jaki przekazujemy, inne zmienne w sumie mozna tez przez konstruktor przekazac 
    			// TODO Auto-generated method stub
    			try{
    				
    				
    				nowaData=Output.getText().toString().trim();
    				nowyTekst=tekstWydarzenia.getText().toString();
    		        String link="http://student.agh.edu.pl/~jpelczar/wys.php"; 
    	            String data  = URLEncoder.encode("user", "UTF-8") 
    	    	            + "=" + URLEncoder.encode(user.getLogin(), "UTF-8");
    	
    	            URL url = new URL(link);
    	            URLConnection conn = url.openConnection(); 
    	            conn.setDoOutput(true); 
    	            OutputStreamWriter wr = new OutputStreamWriter
    	            (conn.getOutputStream()); 
    	            wr.write( data ); 
    	            wr.flush(); 
    	            BufferedReader reader = new BufferedReader
    	            (new InputStreamReader(conn.getInputStream()));
    	            StringBuilder sb = new StringBuilder();
    	            String line = null; //do tad wszystko to mui byc, ponizej czytamy co dostalismy z serwera
    	            // Read Server Response
    	            while((line = reader.readLine()) != null)
    	            {
    	               sb.append(line); 
    	               
    	             
    	            }

    	            return sb.toString();
    	         }catch(Exception e){
    	            return new String("Exception: " + e.getMessage());
    	         }
    		}

    		protected void onPostExecute(String result){  // to co po wykonaniu sie zrobi

    			String[] tmp = new String[2]; //dzielenie wynikow
    			tmp = result.split("\\:",2);
    			//tmp[0] = tmp[0].substring(1, tmp[0].length());
    			int rozmiar = Integer.parseInt(tmp[0]);
    			String[] rekordy = new String[rozmiar];
    			
    			rekordy = tmp[1].split("\\:",rozmiar);
    			wysw.setText("");
    			for (int i =0; i< rozmiar;i++){
    				wysw.append(rekordy[i] + " \n ");
    			}

    				
    				}
    				}
    	   
       }
       
       
       
       
       
       
       
       
       
       
       

