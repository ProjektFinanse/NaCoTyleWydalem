package com.NCTW;

import java.io.Serializable;
import java.util.Date;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;



class Kategoria implements Serializable{ //NIE MA JEJ W DIAGRAMIE, TRZEBA BY DODAĆ
	
	private String nazwa;
	private Bitmap img;
	private int numerid;
	
	public Kategoria(int nr, String n){
		this.nazwa=n;
		this.numerid=nr;
	}
	
	public int getNumerid(){
		return numerid;
	}
	public void setNumerid(int nr){
		this.numerid=nr;
	}
	
	public String getNazwa() {
		return nazwa;
	}
	public void setNazwa(String nazwa) {
		this.nazwa = nazwa;
	}
	public Bitmap getImg() {
		return img;
	}
	public void setImg(String source) { // nie wiem czy działa :)
		
		this.img = BitmapFactory.decodeFile(source);
	}
	
}

class Waluta implements Serializable{
	private String nazwaWaluty;
	private int nrWaluty;
	
	public String getNazwaWaluty(){
		return nazwaWaluty;
	}
	public void setNazwaWaluty(String n){
		this.nazwaWaluty=n;
	}
	public int getNrWaluty(){
		return nrWaluty;
	}
	public void setNrWaluty(int n){
		this.nrWaluty=n;
	}
	public Waluta(int n, String nazwa){
		this.nazwaWaluty=nazwa;
		this.nrWaluty=n;
	}
}

class FormaPlatnosci implements Serializable{
	private String nazwaFormy;
	private int nrFormy;
	
	public FormaPlatnosci(int n, String nazwa){
		this.nazwaFormy=nazwa;
		this.nrFormy=n;
	}
	public String getNazwaFormy(){
		return nazwaFormy;
	}
	public void setNazwaFormy(String n){
		this.nazwaFormy=n;
	}
	public int getNrFormy(){
		return nrFormy;
	}
	public void setNrFormy(int nr){
		this.nrFormy=nr;
	}
}

 

abstract class  Konto{
	
	
	
}




class KontoUzytkownika extends Konto implements Serializable{
	
	private User user;
	private float bilans;
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public float getBilans() {
		return bilans;
	}
	public void setBilans(KontoPieniadze kp) {
		this.bilans = kp.getStanKonta();
	}

	
	
	
}

abstract class Operacje {
	
	public float koszt;
	public int id_waluta;
	public int id_formapl;
	public int id_cykl;
	public String komentarz;
	public int id_kategoria;
	public User user;
	public Date data;
	abstract void dodaj(float Kwota, Kategoria kategoria);
	abstract void usun(long ID); //Id musi byc widoczne zeby mozna byl ousunac po ID albo przekazywac je do funkcji po kliknieciu
	
}

class Wydatki extends Operacje implements Serializable{
	
private long ID;

	

	@Override
	void dodaj(float Kwota, Kategoria kategoria) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void usun(long id_delete) {
		// TODO Auto-generated method stub
		
	}
	public int getKategoria(){
		return id_kategoria;
	}
	public void setKategoria(int id_k){
		this.id_kategoria=id_k;
	}
	public String getData(){
		return data.toString();
	}
	
	public String getUser(){
		return user.getLogin();
	}
	public void setUser(User u){
		this.user=u;
	}

	public long getID() {
		return ID;
	}

	public void setID(long iD) {
		ID = iD;
	}
	//------------------------------
	
	public float getKoszt(){
		return koszt;
		
	}
	public void setKoszt(float k){
		 this.koszt=k;
	}
	
	public int getWaluta(){
		return id_waluta;
	}
	public void setWaluta(int id_w){
		this.id_waluta=id_w;
	}
	public int getFormapl(){
		return id_formapl;
	}
	public void setFormapl(int forma){
		this.id_formapl=forma;
	}
	
	
	public void setKomentarz(String kom){
		this.komentarz=kom;
	}

	public String getKomentarz() {
		// TODO Auto-generated method stub
		return komentarz;
	}

	
}

class Przychody extends Operacje implements Serializable{

	private long ID;
	
	@Override
	void dodaj(float Kwota, Kategoria kategoria) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void usun(long id_delete) {
		// TODO Auto-generated method stub
		
	}

	public long getID() {
		return ID;
	}

	public void setID(long iD) {
		ID = iD;
	}
	
}


class Kalendarz implements Serializable{ // Nie mam pojecia co tutaj, dodaj tu Karolina co CI potrzeba
	public int idWydarzenia;
	public String nazwaWydarzenia;
	public Date dataWydarzenia;
	public User user;
	
	public int getidWydarzenia(){
		return idWydarzenia;
	}
	public String getnazwaWydarzenia(){
		return nazwaWydarzenia;
	}
	public Date getDataWydarzenia(){
		return dataWydarzenia;
	}
}

class Skarbonka implements Serializable{ // Nie mam pojecia co tutaj, dodaj tu Milena co CI potrzeba
	public int idSkarbonka;
	public String NazwaSkarbonki;
	
	public Skarbonka(int n, String nazwa) {
		this.idSkarbonka=n;
		this.NazwaSkarbonki=nazwa;
	}
	public int getidSkarbonki(){
		return idSkarbonka;
	}
	public String getNazwaSkarbonki(){
		return NazwaSkarbonki;
	}
	
}


class Classes {

}

