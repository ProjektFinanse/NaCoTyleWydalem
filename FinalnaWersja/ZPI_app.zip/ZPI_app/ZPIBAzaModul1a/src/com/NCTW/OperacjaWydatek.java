package com.NCTW;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.Date;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;

public class OperacjaWydatek extends AsyncTask<Wydatki,Void,String>{

	private Context context;
	private View view;
	private Date data;
	private int kat;
	private int forma;
	private int wal;
	private String ilekoszt;

	public static String res;
	public WalletActivity wAc;
	
	public OperacjaWydatek(Context context,View view1, Date d, int id_kategorii, int id_formypl, int id_waluta, String kwota) { 
		// TODO Auto-generated constructor stub
		this.context = context;
		this.view = view1;
		this.data=d;
		this.kat=id_kategorii;
		this.forma=id_formypl;
		this.wal=id_waluta;
		this.ilekoszt=kwota;
		wAc = (WalletActivity) context;
	}
	
	
	@Override
	protected void onPreExecute(){ 
		
	   }
	
	protected String doInBackground(Wydatki... params) {
		try{
			
			Wydatki wydatek = (Wydatki)params[0]; 
		
	        String link="http://student.agh.edu.pl/~jpelczar/dodanieWydatku.php"; 
            String data  = URLEncoder.encode("koszt", "UTF-8") 
            + "=" + URLEncoder.encode(Float.toString(wydatek.getKoszt()), "UTF-8");
            data += "&" + URLEncoder.encode("waluta", "UTF-8") 
            + "=" + URLEncoder.encode(Integer.toString(wydatek.getWaluta()), "UTF-8");
            data += "&" + URLEncoder.encode("formapl", "UTF-8") 
            + "=" + URLEncoder.encode(Integer.toString(wydatek.getFormapl()), "UTF-8");
            data += "&" + URLEncoder.encode("kategoria", "UTF-8") 
            + "=" + URLEncoder.encode(Integer.toString(wydatek.getKategoria()), "UTF-8");
            data += "&" + URLEncoder.encode("nazwa", "UTF-8") 
            + "=" + URLEncoder.encode(wydatek.getKomentarz(), "UTF-8");
            data += "&" + URLEncoder.encode("uzytk", "UTF-8") 
            + "=" + URLEncoder.encode(wydatek.getUser(), "UTF-8");
            data += "&" + URLEncoder.encode("data", "UTF-8") 
            + "=" + URLEncoder.encode(wydatek.getData(), "UTF-8");
            URL url = new URL(link);
            URLConnection conn = url.openConnection(); 
            conn.setDoOutput(true); 
            OutputStreamWriter wr = new OutputStreamWriter
            (conn.getOutputStream()); 
            wr.write( data ); 
            wr.flush(); 
            BufferedReader reader = new BufferedReader
            (new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;
         
            while((line = reader.readLine()) != null)
            {
               sb.append(line); 
               
               break;
            }

            return sb.toString();
         }catch(Exception e){
            return new String("Exception: " + e.getMessage());
         }
	} 

	@Override
	   protected void onPostExecute(String result){  // to co po wykonaniu sie zrobi

		/*String er = "error";
			if (!result.equals(er)) { wAc.startWydatki(view); }
			else 	{ wAc.status.setText(result + " login or pass"); }*/
	   }





}
