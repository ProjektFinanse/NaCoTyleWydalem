package com.NCTW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;










import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;


public class StworzSkarbonke  extends Activity implements OnItemSelectedListener{

	User user;
	EditText nazwa, cel, suma;
	Spinner wybierzWalute;
	TextView t1;
	Button stworzSwinke;
	ArrayList<Waluta> listaWaluta;
	private String URL_Waluta="http://student.agh.edu.pl/~jpelczar/pobierzWalute.php";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_skarbonka);
		
		
		
		nazwa=(EditText) this.findViewById(R.id.editNazwaSkarbonki);
		cel=(EditText) this.findViewById(R.id.editCel);
		suma=(EditText) this.findViewById(R.id.editKwota);
		wybierzWalute=(Spinner) this.findViewById(R.id.spinnerWaluta);
		user = new User();
		Bundle extras = getIntent().getExtras();
		user = (User)extras.get("user_data");
	    t1=(TextView) this.findViewById(R.id.textSpr);
	    listaWaluta = new ArrayList<Waluta>();
	    wybierzWalute.setOnItemSelectedListener(this);
		
		
	    stworzSwinke=(Button) this.findViewById(R.id.bStworzSkarbonke);
		stworzSwinke.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
			new NowaSkarbonka().execute(user);
				
			}
		});
		
		
		new GetWaluta().execute();
	}
	
	
	private class GetWaluta extends AsyncTask<Void, Void, Void> {
		 
        protected void onPreExecute() {
          
        }
 
        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String json = jsonParser.makeServiceCall(URL_Waluta, ServiceHandler.GET);
 
            Log.e("Response: ", "> " + json);
 
            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categories = jsonObj.getJSONArray("Waluta");                       
 
                        for (int i = 0; i < categories.length(); i++) {
                            JSONObject catObj = (JSONObject) categories.get(i);
                            Waluta cat = new Waluta(catObj.getInt("idWaluta"), catObj.getString("Nazwa"));
                            listaWaluta.add(cat);
                        }
                    }
 
                } catch (JSONException e) {
                    e.printStackTrace();
                }
 
            } else {
                Log.e("JSON Data", "Didn't receive any data from server!");
            }
			return null;
			
 
            
        }
 
        protected void onPostExecute(Void result) {
        	 super.onPostExecute(result);
        	 populateSpinnerWaluta();
        }
 
    }
	
    private void populateSpinnerWaluta() {
        List<String> lables = new ArrayList<String>();
         
        //txtCategory.setText("");
 
        for (int i = 0; i < listaWaluta.size(); i++) {
            lables.add(listaWaluta.get(i).getNazwaWaluty());
        }
 
        // Creating adapter for spinner
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);
        // Drop down layout style - list view with radio button
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        wybierzWalute.setAdapter(spinnerAdapter);
    }
	
	public class NowaSkarbonka extends AsyncTask<User, Void, String> {

		String nowaNazwa;
		String nowyCel;
		String nowyKoszt;
		String nowaWaluta;
		String nowyUzytkownik;
	    @Override
	    protected void onPreExecute() {
	        super.onPreExecute();
	     
	    }

			
			@Override
			protected String doInBackground(User... params) {
			try{
				
			 nowaNazwa=nazwa.getText().toString();
			 nowyCel=cel.getText().toString();
			 nowyKoszt=suma.getText().toString();
			 nowaWaluta=Long.toString(wybierzWalute.getItemIdAtPosition(wybierzWalute.getSelectedItemPosition())+1);
			 nowyUzytkownik=params[0].getLogin().toString();
				
				
		        String link="http://student.agh.edu.pl/~jpelczar/stworzSkarbonke.php";

	            String data  = URLEncoder.encode("nazwa", "UTF-8") 
	            + "=" + URLEncoder.encode(nowaNazwa, "UTF-8");
	            data += "&" + URLEncoder.encode("cel", "UTF-8") 
	            + "=" + URLEncoder.encode(nowyCel, "UTF-8");
	            data += "&" + URLEncoder.encode("koszt", "UTF-8") 
	    	    + "=" + URLEncoder.encode(nowyKoszt, "UTF-8");
	            data += "&" + URLEncoder.encode("waluta", "UTF-8") 
	    	            + "=" + URLEncoder.encode(nowaWaluta, "UTF-8");
	            data += "&" + URLEncoder.encode("uzytk", "UTF-8") 
	    	            + "=" + URLEncoder.encode(nowyUzytkownik, "UTF-8");
	            URL url = new URL(link);
	            URLConnection conn = url.openConnection(); 
	            conn.setDoOutput(true); 
	            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream()); 
	            wr.write( data ); 
	            wr.flush(); 

	            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = null; 
	            // Read Server Response
	            while((line = reader.readLine()) != null)
	            {
	               sb.append(line); 
	               
	               
	            }

	            return sb.toString();
	         }catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				return e.getMessage();
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				return e.getMessage();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				return e.getMessage();
			}

			}
	    

	    protected void onPostExecute(String result) {
	    	
	    	t1.setText(result);
	    }

			
		

		
	}




	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
