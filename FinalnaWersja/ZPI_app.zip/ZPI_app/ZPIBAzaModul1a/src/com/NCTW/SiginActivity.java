package com.NCTW;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SiginActivity extends Activity {

	private EditText login, pass, repass, mail;
	public TextView tv;
	public String loginStr, passStr, repassStr, mailStr;
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sigin);
		login = (EditText) this.findViewById(R.id.editTextDP);
		pass = (EditText) this.findViewById(R.id.editText2DK);
		repass = (EditText) this.findViewById(R.id.editText3);
		mail = (EditText) this.findViewById(R.id.editText4);
		tv = (TextView) this.findViewById(R.id.textView1);
	}
	
	public void siginStart(View view){
		loginStr = login.getText().toString();
		passStr = pass.getText().toString();
		repassStr = repass.getText().toString();
		mailStr = mail.getText().toString();
		if (!passStr.equals(repassStr)){
			tv.setText("Hasła nie są zgodne");
		}
		else {
			
			new Sigin(this,view).execute(loginStr,passStr,mailStr);
			
		}
		
		
	}
}
