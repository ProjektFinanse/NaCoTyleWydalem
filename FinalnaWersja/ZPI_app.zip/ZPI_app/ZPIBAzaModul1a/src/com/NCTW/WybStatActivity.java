package com.NCTW;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class WybStatActivity extends Activity {

	User user;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_wyb_stat);
		user = new User();
		Bundle extras = getIntent().getExtras();
		user = (User)extras.get("user_data");
	}
	
	public void wybWydatki(View view){
		
		Intent intMenu = new Intent(WybStatActivity.this, StatisticActivity.class); // Okreslamy ktore ma się  otworzyć - tu z Main mamy przejść do MEnu
		intMenu.putExtra("user_data", user); // dodajemy extra dane uzytkownika do tego żeby inne activity tez  wiedziały kto jest zalogowany
		intMenu.putExtra("co", 0);
		WybStatActivity.this.startActivity(intMenu);
		
	}
	public void wybPrzychody(View view){
		
		Intent intMenu = new Intent(WybStatActivity.this,StatisticActivity.class); // Okreslamy ktore ma się  otworzyć - tu z Main mamy przejść do MEnu
		intMenu.putExtra("user_data", user); // dodajemy extra dane uzytkownika do tego żeby inne activity tez  wiedziały kto jest zalogowany
		intMenu.putExtra("co", 1);
		WybStatActivity.this.startActivity(intMenu);
		
	}
}
