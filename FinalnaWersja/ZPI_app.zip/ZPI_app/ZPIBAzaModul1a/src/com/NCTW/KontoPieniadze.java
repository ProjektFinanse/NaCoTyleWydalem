package com.NCTW;

import java.io.Serializable;
import java.util.Date;

public class KontoPieniadze extends Konto implements Serializable{
	
	private User user;
	private Date data_pocztek;
	private Date data_koniec;
	private float suma_wydatki;
	private float suma_przychody;
	private float stanKonta = suma_przychody - suma_wydatki;
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Date getData_pocztek() {
		return data_pocztek;
	}
	public void setData_pocztek(Date data_pocztek) {
		this.data_pocztek = data_pocztek;
	}
	public Date getData_koniec() {
		return data_koniec;
	}
	public void setData_koniec(Date data_koniec) {
		this.data_koniec = data_koniec;
	}
	public float getSuma_wydatki() {
		return suma_wydatki;
	}
	public void setSuma_wydatki(float suma_wydatki) {
		this.suma_wydatki = suma_wydatki;
	}
	public float getSuma_przychody() {
		return suma_przychody;
	}
	public void setSuma_przychody(float suma_przychody) {
		this.suma_przychody = suma_przychody;
	}
	public float getStanKonta() {
		return stanKonta;
	}
	public void setStanKonta(float stanKonta) {
		this.stanKonta = stanKonta;
	}
	
	
}