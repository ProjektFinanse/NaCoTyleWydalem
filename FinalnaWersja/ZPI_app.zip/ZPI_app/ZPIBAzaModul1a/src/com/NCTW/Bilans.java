package com.NCTW;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Date;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.jjoe64.graphview.*;
import com.jjoe64.graphview.GraphView.GraphViewData;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.View;
import android.widget.TextView;

public class Bilans extends AsyncTask<User,Void,String>{ // tu pierwsze to user bo takei cos przekazujemy w doInBeckground
	
	private Context context;
	private View view;
	



	public static String res;
	public MenuActivity sAc;
	User user;



	public Bilans(Context context) { //konstruktor 
		// TODO Auto-generated constructor stub
		this.context = context;
		//sAc = (MenuActivity) context;
	}

	@Override
	protected void onPreExecute(){ //to co na poczatku przed wykonaniem sie stanie
		
	      
	   }

	@Override
	protected String doInBackground(User... params) { // te parametry w execute sa przekazywane tu, specyfikujemy tu tyop jaki przekazujemy, inne zmienne w sumie mozna tez przez konstruktor przekazac 
		// TODO Auto-generated method stub
		try{
			user = (User)params[0]; // a tu je parsujemy do naszego typu i przypisujemy do naszej zmiennej
	      //  String password = (String)params[1]; // to jest pozostalosc po starej 
	        String link="http://student.agh.edu.pl/~jpelczar/bilans.php"; //tu link do strony która wywola kwerende, mozemy przechwycic wszystko co na stronie bedzie echo 
            String data  = URLEncoder.encode("username", "UTF-8") 
            + "=" + URLEncoder.encode(user.getLogin(), "UTF-8");
            URL url = new URL(link);
            URLConnection conn = url.openConnection(); 
            conn.setDoOutput(true); 
            OutputStreamWriter wr = new OutputStreamWriter
            (conn.getOutputStream()); 
            wr.write( data ); 
            wr.flush(); 
            BufferedReader reader = new BufferedReader
            (new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null; 
            // Read Server Response
            while((line = reader.readLine()) != null)
            {
               sb.append(line); 
            
            }

            return sb.toString();
         }catch(Exception e){
            return new String("Exception: " + e.getMessage());
         }
	}


	@Override
	   protected void onPostExecute(String result){ 
		
		
		
		
		
		String[] tmp = new String[2];
		tmp = result.split("\\+",3);
		
		int rozmiarW = Integer.parseInt(tmp[0]);
		int rozmiarP = Integer.parseInt(tmp[1]);
		String[] rekordyP = new String[rozmiarP+1];
		String[] rekordyW = new String[rozmiarW+1];
		String[] rekordy = new String[2];
		
		rekordy = tmp[2].split("\\+",2);
		rekordyP = rekordy[1].split("\\:",rozmiarP+1);
		rekordyW = rekordy[0].split("\\:",rozmiarW+1);


		/*for(int i =0; i < rozmiarP; i++){
			rekordyP[i].replace(":", "");
			rekordyP[i].replace("+", "");
			rekordyP[i].trim();
			
		}
		for(int i =0; i < rozmiarW; i++){
			rekordyW[i].replace(":", "");
			rekordyW[i].replace("+", "");
			rekordyW[i].trim();
			
		}*/
		
		float p = 0,w = 0,b;
		
	
		for(int i =0; i < rozmiarP; i++){
			p += Float.valueOf(rekordyP[i]);
			
		}
		for(int i =0; i < rozmiarW; i++){
			w += Float.valueOf(rekordyW[i]);
			
		}
		
		
		b = p - w;
		
		
		user.kontoPien.setSuma_przychody(p);
		user.kontoPien.setSuma_wydatki(w);
		user.kontoPien.setStanKonta(b);
	}
		
}
