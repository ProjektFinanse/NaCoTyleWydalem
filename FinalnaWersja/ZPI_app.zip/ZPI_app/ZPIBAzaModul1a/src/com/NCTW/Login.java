package com.NCTW;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.View;
import android.widget.TextView;

public class Login extends AsyncTask<User,Void,String>{ // tu pierwsze to user bo takei cos przekazujemy w doInBeckground
	
	private Context context;




	public static String res;
	public MainActivity mAc;

	public Login(Context context) { //konstruktor 
		// TODO Auto-generated constructor stub
		this.context = context;

		mAc = (MainActivity) context;
	}

	@Override
	protected void onPreExecute(){ //to co na poczatku przed wykonaniem sie stanie
		mAc.status.setText("Logowanie w toku...");
	      
	   }

	@Override
	protected String doInBackground(User... params) { // te parametry w execute sa przekazywane tu, specyfikujemy tu tyop jaki przekazujemy, inne zmienne w sumie mozna tez przez konstruktor przekazac 
		// TODO Auto-generated method stub
		try{
			User user = (User)params[0]; // a tu je parsujemy do naszego typu i przypisujemy do naszej zmiennej
	      //  String password = (String)params[1]; // to jest pozostalosc po starej 
	        String link="http://student.agh.edu.pl/~jpelczar/login.php"; //tu link do strony która wywola kwerende, mozemy przechwycic wszystko co na stronie bedzie echo 
            String data  = URLEncoder.encode("username", "UTF-8") 
            + "=" + URLEncoder.encode(user.getLogin(), "UTF-8");
            data += "&" + URLEncoder.encode("password", "UTF-8") 
            + "=" + URLEncoder.encode(user.getPassword(), "UTF-8");
            URL url = new URL(link);
            URLConnection conn = url.openConnection(); 
            conn.setDoOutput(true); 
            OutputStreamWriter wr = new OutputStreamWriter
            (conn.getOutputStream()); 
            wr.write( data ); 
            wr.flush(); 
            BufferedReader reader = new BufferedReader
            (new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null; //do tad wszystko to mui byc, ponizej czytamy co dostalismy z serwera
            // Read Server Response
            while((line = reader.readLine()) != null)
            {
               sb.append(line); 
               
               break;
            }

            return sb.toString();
         }catch(Exception e){
            return new String("Exception: " + e.getMessage());
         }
	}

	@Override
	   protected void onPostExecute(String result){  // to co po wykonaniu sie zrobi

		String er = "error";
			if (!result.equals(er)) { mAc.status.setText("Logowanie zakończone"); mAc.startMenu(); }
			else 	{ mAc.status.setText(result + " login or pass"); }
	   }
	
}
