package com.NCTW;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class UserActivity extends Activity {
	
	TextView tv;
	View view;
	KontoPieniadze kp;
	User user; 
	TextView stanPortfela;
	TextView email;
	String mItemSelectedMessageTemplate;
	String mItemSelectedMessageTemplate2;
	Spinner spin;
	//Spinner spin2;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_user);
		user = new User();
		tv = (TextView)this.findViewById(R.id.textLogin);
		stanPortfela=(TextView)this.findViewById(R.id.textBilans);
		email=(TextView)this.findViewById(R.id.textMail);
		
		
		Bundle extras = getIntent().getExtras();
		user = (User)extras.get("user_data");
		tv.setText(user.getLogin());
		stanPortfela.setText(String.valueOf(user.kontoPien.getStanKonta()));
		new DajMaila().execute(user);

	}
	
	
	
	private class DajMaila extends AsyncTask<User, Void, String>{
		@Override
		protected String doInBackground(User... params) {
			try{
				User user = (User)params[0]; // a tu je parsujemy do naszego typu i przypisujemy do naszej zmiennej
		      //  String password = (String)params[1]; // to jest pozostalosc po starej 
		        String link="http://student.agh.edu.pl/~jpelczar/pobierzMaila.php"; //tu link do strony ktĂłra wywola kwerende, mozemy przechwycic wszystko co na stronie bedzie echo 
	            String data  = URLEncoder.encode("username", "UTF-8") 
	            + "=" + URLEncoder.encode(user.getLogin(), "UTF-8");
	            URL url = new URL(link);
	            URLConnection conn = url.openConnection(); 
	            conn.setDoOutput(true); 
	            OutputStreamWriter wr = new OutputStreamWriter
	            (conn.getOutputStream()); 
	            wr.write( data ); 
	            wr.flush(); 
	            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = null; //do tad wszystko to mui byc, ponizej czytamy co dostalismy z serwera
	            // Read Server Response
	            while((line = reader.readLine()) != null)
	            {
	               sb.append(line); 
	               
	              	            }
	            return sb.toString();
	         }catch(Exception e){
	            return new String("Exception: " + e.getMessage());
	         }
			
		}
		protected void onPostExecute(String result){
			email.setText(result);
		}
		
	}
		
	}