package com.NCTW;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends Activity { //tesotwe login i haslo to test
	
	
	protected EditText  usLogin;
	private EditText usPass;
	protected TextView status;
	private ImageButton login,sigin;
	public User user;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		usLogin = (EditText)this.findViewById(R.id.editTextDP);
		usPass = (EditText)this.findViewById(R.id.editText2DK);
		login = (ImageButton)this.findViewById(R.id.imageButton1);
		sigin = (ImageButton)this.findViewById(R.id.imageButton2);
		status = (TextView)this.findViewById(R.id.textView1);
		user = new User();
		user.kontoPien = new KontoPieniadze();

		
		login.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				user.setLogin(usLogin.getText().toString());
				user.setPassword( usPass.getText().toString());

				
				new Login(MainActivity.this).execute(user);
				
			}
			
		});
		
		sigin.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intSigin = new Intent(MainActivity.this, SiginActivity.class);
				MainActivity.this.startActivity(intSigin);
				
			}
			
		});

	}
	
public void startMenu(){
	
	Intent intMenu = new Intent(MainActivity.this, MenuActivity.class); // Okreslamy ktore ma się  otworzyć - tu z Main mamy przejść do MEnu
	intMenu.putExtra("user_data", user); // dodajemy extra dane uzytkownika do tego żeby inne activity tez  wiedziały kto jest zalogowany
	MainActivity.this.startActivity(intMenu); // startujemy nowe okno
	
}
	/*
public void startSigin(View view){
		

	Intent intSigin = new Intent(MainActivity.this, SiginActivity.class);
	MainActivity.this.startActivity(intSigin);
				
	}

public void login(View view){
	
	user.setLogin(usLogin.getText().toString());
	user.setPassword( usPass.getText().toString());

	
	new Login(this).execute(user); //wykonujemy logowanie - każda klase z AsyncTask tak sie wywoluje - kazða klasa do pobierania danych u nas bedzie z Async Task wiec kazda tak trzeba bedzie ywyolac
			
}*/
}
