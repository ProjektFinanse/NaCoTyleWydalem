package com.NCTW;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

public class MenuActivity extends Activity {
	
	User user;
	Date dp,dk;
	Calendar cal;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu);
		user = new User();
		Bundle extras = getIntent().getExtras();
		user = (User)extras.get("user_data");
		new Bilans(this).execute(user);
	}
	
	
	public void startUser(View view){
		
		Intent inte = new Intent(MenuActivity.this, UserActivity.class);
		inte.putExtra("user_data", user);
		MenuActivity.this.startActivity(inte);
		
	}
	
public void startCalendar(View view){
		
		Intent inte = new Intent(MenuActivity.this, CalendarActivity.class);
		inte.putExtra("user_data", user);
		MenuActivity.this.startActivity(inte);
		
	}

public void startPigg(View view){
	
	Intent inte = new Intent(MenuActivity.this, PiggActivity.class);
	inte.putExtra("user_data", user);
	MenuActivity.this.startActivity(inte);
	
}

public void startWallet(View view){
	
	Intent inte = new Intent(MenuActivity.this, WalletActivity.class);
	inte.putExtra("user_data", user);
	MenuActivity.this.startActivity(inte);
	
}
}
