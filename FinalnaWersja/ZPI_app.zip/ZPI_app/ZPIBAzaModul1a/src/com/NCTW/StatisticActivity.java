package com.NCTW;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.jjoe64.graphview.*;
import com.jjoe64.graphview.GraphView.GraphViewData;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class StatisticActivity extends Activity {


	User user;
	LinearLayout lay;
	GraphViewSeries exampleSeries;
	public GraphView graphView;
	List<String> listData;
	ArrayAdapter<String> dataAdapterData;

	Spinner dp,dk;
	String co;
	Date dPocz, dKon;
	TextView tv,bilans;
	public int what,tmpWhat;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_statistic);
		

		dp = (Spinner) this.findViewById(R.id.spinner2);
		dk = (Spinner) this.findViewById(R.id.spinner3);
		tv = (TextView) this.findViewById(R.id.textView1);
		bilans = (TextView) this.findViewById(R.id.textView4);
		tv.setMovementMethod(new ScrollingMovementMethod());
		
		
		user = new User();
		Bundle extras = getIntent().getExtras();
		user = (User)extras.get("user_data");
		new Bilans(this).execute(user);
		what = (int)extras.getInt("co");
		tmpWhat = what;
		lay = (LinearLayout) this.findViewById(R.id.linley);
		bilans.append(Float.toString(user.kontoPien.getStanKonta()) + " Suma wydatków: " + Float.toString(user.kontoPien.getSuma_wydatki()) + " Suma przychodów: " + Float.toString(user.kontoPien.getSuma_przychody()));
		


		listData = new ArrayList<String>();

		if(what == 0){ user.co = "Wydatki"; new StatisticList(this).execute(user);}
		if(what == 1){ user.co = "Przychody"; new StatisticList(this).execute(user); }

		
		
		

		
		graphView  = new LineGraphView(
			    this // context
			    , "Statystyki" // heading
			);
				
		
		
	}
	
	public void start(View view){
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			try {
				dPocz = df.parse(dp.getSelectedItem().toString());
				dKon = df.parse(dk.getSelectedItem().toString());
				if (dPocz.after(dKon) || dPocz.equals(dKon)){tv.setText("Niepoprawnie wybrane daty"); what = -1;}
				else what = tmpWhat;
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

		
		if (what == 0) { co = "Wydatki.php";  new Statistic(this, view,co,dPocz,dKon).execute(user);}
		else if (what == 1) { co = "Przychody.php";  new Statistic(this, view,co,dPocz,dKon).execute(user);}
	}
	
	public void wyswietl(View view){
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		try {
			dPocz = df.parse(dp.getSelectedItem().toString());
			dKon = df.parse(dk.getSelectedItem().toString());
			if (dPocz.after(dKon) || dPocz.equals(dKon)){tv.setText("Niepoprawnie wybrane daty"); what = -1;}
			else what = tmpWhat;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	
		if (what == 0) { co = "Wydatki.php";  new Wyswietl(this, view,co,dPocz,dKon,1).execute(user);}
		else if (what == 1) { co = "Przychody.php";  new Wyswietl(this, view,co,dPocz,dKon,0).execute(user);}
		
	}
}
