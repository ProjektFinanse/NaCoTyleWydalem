package com.NCTW;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.jjoe64.graphview.*;
import com.jjoe64.graphview.GraphView.GraphViewData;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ArrayAdapter;

public class StatisticList extends AsyncTask<User,Void,String>{ // tu pierwsze to user bo takei cos przekazujemy w doInBeckground

	



	public static String res;
	public StatisticActivity sAc;
	Context con;



	public StatisticList(Context context) { //konstruktor 
		sAc = (StatisticActivity) context;
		con = context;

		
	}

	@Override
	protected void onPreExecute(){ //to co na poczatku przed wykonaniem sie stanie
		
	      
	   }

	@Override
	protected String doInBackground(User... params) { // te parametry w execute sa przekazywane tu, specyfikujemy tu tyop jaki przekazujemy, inne zmienne w sumie mozna tez przez konstruktor przekazac 
		// TODO Auto-generated method stub
		try{
			User user = (User)params[0]; // a tu je parsujemy do naszego typu i przypisujemy do naszej zmiennej			

			String link="http://student.agh.edu.pl/~jpelczar/listaDatStat.php"; //tu link do strony która wywola kwerende, mozemy przechwycic wszystko co na stronie bedzie echo 
            String data  = URLEncoder.encode("username", "UTF-8") 
            + "=" + URLEncoder.encode(user.getLogin(), "UTF-8");
            data  +=   "&" + URLEncoder.encode("co", "UTF-8") 
                    + "=" + URLEncoder.encode(user.co, "UTF-8");
            URL url = new URL(link);
            URLConnection conn = url.openConnection(); 
            conn.setDoOutput(true); 
            OutputStreamWriter wr = new OutputStreamWriter
            (conn.getOutputStream()); 
            wr.write( data ); 
            wr.flush(); 
            BufferedReader reader = new BufferedReader
            (new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null; 
            // Read Server Response
            while((line = reader.readLine()) != null)
            {
               sb.append(line + " "); 
             
            
            }


            return sb.toString();
         }catch(Exception e){
            return new String("Exception: " + e.getMessage());
         }
	}


	@Override
	   protected void onPostExecute(String result){ 
		
		
		
		
		String[] tmp = new String[2]; //dzielenie wynikow
		tmp = result.split("\\:",2);
		
		tmp[0] = tmp[0].substring(1, tmp[0].length());
		
		int rozmiar = Integer.parseInt(tmp[0]);
		String[] rekordy = new String[rozmiar];
		//sAc.tv.append("r: " + rozmiar + " " );
		
		rekordy = tmp[1].split("\\:",rozmiar);
		for (int i = 0; i < rozmiar;i++){
			rekordy[i] = rekordy[i].substring(0,10);
		}
		
		int tmpRoz = 0;
		
		for (int i =0; i < rozmiar-1; i++){ 
			if (rekordy[i].equals(rekordy[i+1])) tmpRoz++;			
	}
		//sAc.tv.setText(tmpRoz + " " + rozmiar);
		if (tmpRoz != 0){
		String [] daty = new String[rozmiar];
		
		int tmpa = 0;
		
		for (int i = 0; i < rozmiar; i++){
			
			if (i+1<rozmiar){
			if (rekordy[i].equals(rekordy[i+1])) { if(i+1 == rozmiar-1) {daty[tmpa] = rekordy[i]; tmpa++; break;} continue;}
			else if ((i+1 == rozmiar-1)) { daty[tmpa] = rekordy[i]; tmpa++;daty[tmpa] = rekordy[i+1]; }
			else {
				daty[tmpa] = rekordy[i];
				tmpa++;
			}
			}
			else{
				daty[tmpa] = rekordy[i];
				tmpa++;
			}
			
			
		}
		//sAc.tv.append("aaaaa  " + tmpa + "aaaaaaaa");
		for (int i =0; i < tmpa; i++){ 
			sAc.listData.add(daty[i]);
			//sAc.tv.append(daty[i]);
			
	}
		}
		else {
			
			for (int i =0; i < rozmiar; i++){ 
				sAc.listData.add(rekordy[i]);
				//sAc.tv.append(rekordy[i]);
				
		}
		}
		
		try{
		sAc.dataAdapterData = new ArrayAdapter<String>(sAc,android.R.layout.simple_spinner_item, sAc.listData);
		sAc.dataAdapterData.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		sAc.dp.setAdapter(sAc.dataAdapterData);
		sAc.dk.setAdapter(sAc.dataAdapterData);
		}
		catch(Exception e){
			//sAc.tv.append("pusto");
		}

	
	}
}
