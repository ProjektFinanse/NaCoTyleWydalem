package com.NCTW;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.Date;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;

public class Sigin extends AsyncTask<String,Void,String>{ 
	
	private Context context;
	private View view;
	private Date date;
	private Calendar cal;
	String dat;



	public static String res;
	public SiginActivity sAc;

	public Sigin(Context context,View view1) { //konstruktor 
		// TODO Auto-generated constructor stub
		this.context = context;
		this.view = view1;
		String minuta;
		cal = Calendar.getInstance();
		if (cal.get(Calendar.MINUTE) < 10){
			minuta = "0"+cal.get(Calendar.MINUTE);
		}
		else minuta = "" + cal.get(Calendar.MINUTE);
		
		String sec;
		
		if (cal.get(Calendar.SECOND) < 10){
			sec = "0"+cal.get(Calendar.SECOND);
		}
		else sec= "" + cal.get(Calendar.SECOND);
		
		dat = ""+  cal.get(Calendar.YEAR) + "-" + cal.get(Calendar.MONTH) + "-" + cal.get(Calendar.DAY_OF_MONTH) + " " + cal.get(Calendar.HOUR_OF_DAY) + ":" + minuta + ":" + sec; 
		sAc = (SiginActivity) context;
	}

	@Override
	protected void onPreExecute(){ 
		
	      
	   }

	@Override
	protected String doInBackground(String... params) { 
		// TODO Auto-generated method stub
		try{
			String login = (String)params[0]; 
	        String password = (String)params[1];
	        String mail = (String)params[2];
	        String link="http://student.agh.edu.pl/~jpelczar/sigin.php";
            String data  = URLEncoder.encode("username", "UTF-8") 
            + "=" + URLEncoder.encode(login, "UTF-8");
            data += "&" + URLEncoder.encode("password", "UTF-8") 
            + "=" + URLEncoder.encode(password, "UTF-8");
            data += "&" + URLEncoder.encode("mail", "UTF-8") 
             + "=" + URLEncoder.encode(mail, "UTF-8");
            data += "&" + URLEncoder.encode("data", "UTF-8") 
            + "=" + URLEncoder.encode(dat, "UTF-8");
            URL url = new URL(link);
            URLConnection conn = url.openConnection(); 
            conn.setDoOutput(true); 
            OutputStreamWriter wr = new OutputStreamWriter
            (conn.getOutputStream()); 
            wr.write( data ); 
            wr.flush(); 
            BufferedReader reader = new BufferedReader
            (new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null; 
            // Read Server Response
            while((line = reader.readLine()) != null)
            {
               sb.append(line); 
               
               
            }

            return sb.toString();
         }catch(Exception e){
            return new String("Exception: " + e.getMessage());
         }
	}

	@Override
	   protected void onPostExecute(String result){  

			sAc.tv.setText(result + '\n');
			sAc.tv.append("Rejestracja Ukończona");
	   }
	
}
