package com.NCTW;

import java.io.Serializable;

public class User  implements Serializable{
	
	private String login;
	private String password;
	private Boolean type;	
	public String co;
	public KontoPieniadze  kontoPien;
	
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Boolean getType() {
		return type;
	}
	public void setType(Boolean type) {
		this.type = type;
	}
	
}
