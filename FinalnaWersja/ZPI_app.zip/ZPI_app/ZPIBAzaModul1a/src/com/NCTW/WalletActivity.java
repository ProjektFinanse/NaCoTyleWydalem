package com.NCTW;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.appcompat.R.id;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class WalletActivity extends Activity {

	User user;
	Kategoria kategoria;
	//private Button p;
	//private Button w;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_wallet);
		user = new User();
		Bundle extras = getIntent().getExtras();
		user = (User)extras.get("user_data");

	}
	public void startStatystyki(View view){
		
		Intent intMenu = new Intent(WalletActivity.this, WybStatActivity.class); // Okreslamy ktore ma się  otworzyć - tu z Main mamy przejść do MEnu
		intMenu.putExtra("user_data", user); // dodajemy extra dane uzytkownika do tego żeby inne activity tez  wiedziały kto jest zalogowany
		WalletActivity.this.startActivity(intMenu);
		
	}
	
	public void startDodusu(View view){
		
		Intent intMenu = new Intent(WalletActivity.this, WalletWydatki.class); // Okreslamy ktore ma się  otworzyć - tu z Main mamy przejść do MEnu
		intMenu.putExtra("user_data", user); // dodajemy extra dane uzytkownika do tego żeby inne activity tez  wiedziały kto jest zalogowany
		WalletActivity.this.startActivity(intMenu);
		
	}
	
public void startPrzychody(View view){
		
		Intent intPrzychody = new Intent(WalletActivity.this, WalletPrzychody.class);
		intPrzychody.putExtra("user_data", user);
		WalletActivity.this.startActivity(intPrzychody);
		
	}

public void startWydatki(View view){
	
	Intent intWydatki = new Intent(WalletActivity.this, WalletWydatki.class);
	intWydatki.putExtra("user_data", user);
	WalletActivity.this.startActivity(intWydatki);
	
	//new OperacjaWydatek(this, view).execute(konto);
}
}
