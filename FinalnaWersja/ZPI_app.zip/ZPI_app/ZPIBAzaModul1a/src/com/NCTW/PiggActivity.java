package com.NCTW;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class PiggActivity extends Activity implements OnItemSelectedListener {

	User user;
	Button stworz;
	Button nakarm;
	EditText suma;
	TextView tekst;
	Spinner wybierzSkarbonke;
	ArrayList<String> listaSwinek;
	private String URL_Swinka="http://student.agh.edu.pl/~jpelczar/pobierzSkarbonki.php";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pigg);
		
		wybierzSkarbonke=(Spinner) this.findViewById(R.id.spinnerWybierzSwinke);
		user = new User();
		Bundle extras = getIntent().getExtras();
		user = (User)extras.get("user_data");
		suma=(EditText) this.findViewById(R.id.editSumaDoSkarbonki);
		tekst=(TextView) this.findViewById(R.id.textWynikKarmienia);
		stworz=(Button) this.findViewById(R.id.bStworz);
		nakarm=(Button) this.findViewById(R.id.bNakarm);
		
		listaSwinek = new ArrayList<String>();
		wybierzSkarbonke.setOnItemSelectedListener(this);
		
		nakarm.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new nakarmSkarbonke().execute();
			}
		});
		
		new GetSkarbonkaKuba().execute();
	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub
		
	}

	
	public void stworzNowaSkarbonke(View view){
		
		Intent intStworzSkarbonke = new Intent(PiggActivity.this, StworzSkarbonke.class); // Okreslamy ktore ma się  otworzyć - tu z Main mamy przejść do MEnu
		intStworzSkarbonke.putExtra("user_data", user); // dodajemy extra dane uzytkownika do tego żeby inne activity tez  wiedziały kto jest zalogowany
		PiggActivity.this.startActivity(intStworzSkarbonke);
		
	}
	

	/*
	private class GetSkarbonka extends AsyncTask<Void, Void, Void> {
		 
        protected void onPreExecute() {
          
        }
 
        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String json = jsonParser.makeServiceCall(URL_Swinka, ServiceHandler.GET);
 
            Log.e("Response: ", "> " + json);
 
            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categories = jsonObj.getJSONArray("Skarbonka");                       
 
                        for (int i = 0; i < categories.length(); i++) {
                            JSONObject catObj = (JSONObject) categories.get(i);
                            Skarbonka cat = new Skarbonka(catObj.getInt("idSkarbonka"), catObj.getString("Nazwa"));
                            listaSwinek.add(cat);
                        }
                    }
 
                } catch (JSONException e) {
                    e.printStackTrace();
                }
 
            } else {
                Log.e("JSON Data", "Didn't receive any data from server!");
            }
 
            return null;
        }
 
        protected void onPostExecute(Void result) {
        	 super.onPostExecute(result);
        	 populateSpinnerSwinka();
        }
 
    }*/
	
	private class GetSkarbonkaKuba extends AsyncTask<Void, Void, String> {
		 
        protected void onPreExecute() {
          
        }
        
        protected String doInBackground(Void... params) { // te parametry w execute sa przekazywane tu, specyfikujemy tu tyop jaki przekazujemy, inne zmienne w sumie mozna tez przez konstruktor przekazac 
    		// TODO Auto-generated method stub
    		try{
    		

    			String link=URL_Swinka; //tu link do strony która wywola kwerende, mozemy przechwycic wszystko co na stronie bedzie echo 
                String data  = URLEncoder.encode("username", "UTF-8") 
                + "=" + URLEncoder.encode(user.getLogin(), "UTF-8");
                URL url = new URL(link);
                URLConnection conn = url.openConnection(); 
                conn.setDoOutput(true); 
                OutputStreamWriter wr = new OutputStreamWriter
                (conn.getOutputStream()); 
                wr.write( data ); 
                wr.flush(); 
                BufferedReader reader = new BufferedReader
                (new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line = null; 
                // Read Server Response
                while((line = reader.readLine()) != null)
                {
                   sb.append(line + " "); 
                
                }

                return sb.toString();
             }catch(Exception e){
                return new String("Exception: " + e.getMessage());
             }
    	}
 
 
        protected void onPostExecute(String result) {
        	 
        	 
        	 String[] tmp = new String[2]; //dzielenie wynikow
	    		tmp = result.split("\\:",2);
	    		
	    		//tmp[0] = tmp[0].substring(1, tmp[0].length());
	    		
	    		int rozmiar = Integer.parseInt(tmp[0]);
	    		String[] rekordy = new String[rozmiar];
	    		//tekst.append("r: " + rozmiar + " " );
	    		
	    		rekordy = tmp[1].split("\\:",rozmiar);
	    		for (int i = 0; i < rozmiar;i++){
	    			//tekst.append(rekordy[i]);
	    			listaSwinek.add(rekordy[i]);
	    		}
        	 
        	 populateSpinnerSwinka();
        }
 
    }
	
    private void populateSpinnerSwinka() {
        List<String> lables = new ArrayList<String>();
       
 
        for (int i = 0; i < listaSwinek.size(); i++) {
            lables.add(listaSwinek.get(i));
        }
 
        // Creating adapter for spinner
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);
        // Drop down layout style - list view with radio button
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        wybierzSkarbonke.setAdapter(spinnerAdapter);
    }
	
	
	
	public class nakarmSkarbonke extends AsyncTask<String, String, String> {

		String nowyKoszt;
		String nowaSkarbonka;
		String nowyUzytkownik;
	    @Override
	    protected void onPreExecute() {
	        super.onPreExecute();
	     
	    }

			@Override
			protected String doInBackground(String... params) {
			try{
				
			 nowyKoszt=suma.getText().toString();
			 nowaSkarbonka=wybierzSkarbonke.getSelectedItem().toString();
			 nowyUzytkownik=user.getLogin();
				
				
		        String link="http://student.agh.edu.pl/~jpelczar/nakarmSkarbonke.php";

	           
	            String data = "&" + URLEncoder.encode("koszt", "UTF-8") 
	    	    + "=" + URLEncoder.encode(nowyKoszt, "UTF-8");
	            data += "&" + URLEncoder.encode("skarbonka", "UTF-8") 
	    	            + "=" + URLEncoder.encode(nowaSkarbonka, "UTF-8");
	            data += "&" + URLEncoder.encode("uzytk", "UTF-8") 
	    	            + "=" + URLEncoder.encode(nowyUzytkownik, "UTF-8");
	            URL url = new URL(link);
	            URLConnection conn = url.openConnection(); 
	            conn.setDoOutput(true); 
	            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream()); 
	            wr.write( data ); 
	            wr.flush(); 

	            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = null; 
	            // Read Server Response
	            while((line = reader.readLine()) != null)
	            {
	               sb.append(line); 
	               
	               
	            }

	            return sb.toString();
	         }catch(Exception e){
	            return new String("Exception: " + e.getMessage());
	         }

			}
	    

	    protected void onPostExecute(String result) {
	    	
	    	tekst.setText(result);
	    }

			
		

		
	}
	
	
	
	
	
	
	
	
	
}
