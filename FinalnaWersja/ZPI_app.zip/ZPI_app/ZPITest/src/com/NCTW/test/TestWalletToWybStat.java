package com.NCTW.test;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.test.ActivityInstrumentationTestCase2;
import android.test.UiThreadTest;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.NCTW.KontoPieniadze;
import com.NCTW.User;
import com.NCTW.UserActivity;
import com.NCTW.WalletActivity;
import com.NCTW.WalletWydatki;
import com.NCTW.WybStatActivity;

public class TestWalletToWybStat  extends ActivityInstrumentationTestCase2<WalletActivity>{
	
	public TestWalletToWybStat(){
		super("com.NCTW",WalletActivity.class);
	}
	
	WalletActivity mActivity;
	User user;
	CountDownLatch signal;
	ImageView ib;
	
	protected void setUp() throws Exception{
		super.setUp();
		
		user = new User();
		user.setLogin("test");
		user.setPassword("test");
		user.kontoPien =  new KontoPieniadze();
		user.kontoPien.setStanKonta(300);
		Intent addEvent = new Intent();
	    addEvent.setClassName("com.NCTW", "com.NCTW.WalletActivity");
	    addEvent.putExtra("user_data", user);
	    setActivityIntent(addEvent);
	    mActivity = this.getActivity();
	    ib = (ImageView) mActivity.findViewById(com.NCTW.R.id.imageView1);


	
		signal = new CountDownLatch(1);
	}
	@UiThreadTest
	public void testWallet(){
	
		ib.performClick();
		 try {
				signal.await(5, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 ActivityManager manager = (ActivityManager) mActivity.getSystemService(Context.ACTIVITY_SERVICE);
		 List< ActivityManager.RunningTaskInfo > runningTaskInfo = manager.getRunningTasks(1); 
	     ComponentName componentInfo = runningTaskInfo.get(0).topActivity;
	     assertEquals(componentInfo.getClassName(),WybStatActivity.class.getName());

	}
	

}
