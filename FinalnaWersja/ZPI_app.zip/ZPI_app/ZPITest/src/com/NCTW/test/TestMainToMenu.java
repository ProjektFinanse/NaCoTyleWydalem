package com.NCTW.test;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.security.auth.callback.Callback;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Instrumentation;
import android.app.ActivityManager.*;
import android.app.Instrumentation.ActivityMonitor;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.test.ActivityInstrumentationTestCase2;
import android.test.TouchUtils;
import android.test.UiThreadTest;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.NCTW.*;

public class TestMainToMenu extends ActivityInstrumentationTestCase2<MainActivity>{

	
	public TestMainToMenu(){
		super("com.NCTW", MainActivity.class );
	}
	
	
	MainActivity mActivity;
	TextView tv;
	EditText et1, et2;
	View view;
	ImageButton buttonSigin, buttonSigin2;
	String login, pass, expectation;
	CountDownLatch signal;
	User user;
	 

	
	protected void setUp() throws Exception{
		super.setUp();
		mActivity = this.getActivity();
		tv = (TextView) mActivity.findViewById(com.NCTW.R.id.textView1);
		et1 = (EditText)  mActivity.findViewById(com.NCTW.R.id.editTextDP);
		et2 = (EditText)  mActivity.findViewById(com.NCTW.R.id.editText2DK);
		buttonSigin = (ImageButton) mActivity.findViewById(com.NCTW.R.id.imageButton1);

		user = new User();
		user.setLogin("test");
		user.setPassword("test");
		signal = new CountDownLatch(1);

				
		
		
	}
	
			
	 
	 @UiThreadTest
		public void testACheckGUI() {
			assertNotNull(tv);
			assertNotNull(et1);
			assertNotNull(et2);
			assertNotNull(buttonSigin);

		}
	 @UiThreadTest
	 public void testBDLogin(){
		 et1.setText(user.getLogin());
		 et2.setText(user.getPassword());
		 buttonSigin.performClick();
		 
		 ActivityManager manager = (ActivityManager) mActivity.getSystemService(Context.ACTIVITY_SERVICE);
		 List< ActivityManager.RunningTaskInfo > runningTaskInfo = manager.getRunningTasks(1);
		 ComponentName componentInfo = runningTaskInfo.get(0).topActivity;
		 assertEquals(componentInfo.getClassName(),MenuActivity.class.getName());

		 
		 
	 }
	 
	 @UiThreadTest
		public void testBAButton(){
			 
		 expectation = "Logowanie w toku...";
			 
		 
		buttonSigin.performClick();
			
			
			try {
				signal.await(5, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			assertEquals(expectation ,tv.getText().toString());
					
		
			
		}


}
