package com.NCTW.test;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.test.ActivityInstrumentationTestCase2;
import android.test.UiThreadTest;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.NCTW.*;

public class TestMenuToUser extends ActivityInstrumentationTestCase2<MenuActivity>{

	
	public TestMenuToUser(){
		super("com.NCTW", MenuActivity.class );
	}
	
	MenuActivity mActivity;
	User user;
	CountDownLatch signal;
	ImageButton butUser, butLog;
	EditText et1,et2;
	//TextView tv1, tv2, tv3;
	private View inflaterView;
	 

	
	protected void setUp() throws Exception{
		super.setUp();
		
		user = new User();
		user.setLogin("test");
		user.setPassword("test");
		Intent addEvent = new Intent();
	    addEvent.setClassName("com.NCTW", "com.NCTW.MenuActivity");
	    addEvent.putExtra("user_data", user);
	    setActivityIntent(addEvent);
	    mActivity = this.getActivity();

		butUser = (ImageButton) mActivity.findViewById(com.NCTW.R.id.imageButtonUser);
		//tv1 = (TextView) mActivity.findViewById(com.NCTW.R.id.textLogin);
		//tv2 = (TextView) mActivity.findViewById(com.NCTW.R.id.textMail);
		//tv3 = (TextView) mActivity.findViewById(com.NCTW.R.id.textBilans);
		signal = new CountDownLatch(1);
	}
	

	 @UiThreadTest
	 public void testADLogin(){
		 
		
		 assertNotNull(butUser);
		 butUser.performClick();
		 
		 try {
				signal.await(5, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
		 ActivityManager manager = (ActivityManager) mActivity.getSystemService(Context.ACTIVITY_SERVICE);
		 List< ActivityManager.RunningTaskInfo > runningTaskInfo = manager.getRunningTasks(1); 
	     ComponentName componentInfo = runningTaskInfo.get(0).topActivity;
	     assertEquals(componentInfo.getClassName(),UserActivity.class.getName());
		 
		 
	 }

	/* public void testBDUser(){
		 assertNotNull(tv3);
		 assertEquals(tv1.getText().toString(),"test");
		 assertEquals(tv2.getText().toString(),"test@test.pl");
	 }
*/
			
}
