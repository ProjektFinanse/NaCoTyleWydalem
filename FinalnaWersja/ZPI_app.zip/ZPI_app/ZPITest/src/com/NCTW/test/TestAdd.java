package com.NCTW.test;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.test.ActivityInstrumentationTestCase2;
import android.test.UiThreadTest;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.NCTW.KontoPieniadze;
import com.NCTW.User;
import com.NCTW.UserActivity;
import com.NCTW.WalletActivity;
import com.NCTW.WalletWydatki;
import com.NCTW.WybStatActivity;

public class TestAdd  extends ActivityInstrumentationTestCase2<WalletWydatki>{
	
	public TestAdd(){
		super("com.NCTW",WalletWydatki.class);
	}
	
	WalletWydatki mActivity;
	User user;
	Spinner sp1,sp2,sp3;
	EditText et1,et2;
	Button add;
	TextView tv;
	CountDownLatch signal;

	
	protected void setUp() throws Exception{
		super.setUp();
		
		user = new User();
		user.setLogin("test");
		user.setPassword("test");
		user.kontoPien =  new KontoPieniadze();
		user.kontoPien.setStanKonta(300);
		Intent addEvent = new Intent();
	    addEvent.setClassName("com.NCTW", "com.NCTW.WalletWydatki");
	    addEvent.putExtra("user_data", user);
	    setActivityIntent(addEvent);
	    mActivity = this.getActivity();
	    sp1 = (Spinner) mActivity.findViewById(com.NCTW.R.id.spinner1);
	    sp2 = (Spinner) mActivity.findViewById(com.NCTW.R.id.spinner2);
	    sp3 = (Spinner) mActivity.findViewById(com.NCTW.R.id.spinner3);
	    et1 = (EditText) mActivity.findViewById(com.NCTW.R.id.nazwa);
	    et2 = (EditText) mActivity.findViewById(com.NCTW.R.id.editText1);
	    add = (Button) mActivity.findViewById(com.NCTW.R.id.dodajwydatek);
	    tv = (TextView) mActivity.findViewById(com.NCTW.R.id.textView1);
		
	
		signal = new CountDownLatch(1);
	}
	@UiThreadTest
	public void testWallet(){
	
		sp1.setSelection(3);
		sp2.setSelection(2);
		sp3.setSelection(4);
		et1.setText("200");
		et2.setText("UniTest");
		add.performClick();
		 try {
				signal.await(10, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		 assertEquals(tv.getText().toString(),"Dodano");

	}
	

}
