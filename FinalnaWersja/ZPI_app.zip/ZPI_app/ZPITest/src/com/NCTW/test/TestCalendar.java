package com.NCTW.test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import android.content.Intent;
import android.test.ActivityInstrumentationTestCase2;
import android.test.UiThreadTest;
import android.widget.Button;
import android.widget.TextView;

import com.NCTW.CalendarActivity;
import com.NCTW.KontoPieniadze;
import com.NCTW.User;
import com.NCTW.UserActivity;

public class TestCalendar extends ActivityInstrumentationTestCase2<CalendarActivity> {
		
	public TestCalendar(){
		super("com.NCTW",CalendarActivity.class);
	}
	
	CalendarActivity mActivity;
	User user;
	CountDownLatch signal;
	TextView tv1, tv2, tv3;
	Button but;
	
	protected void setUp() throws Exception{
		super.setUp();
		
		user = new User();
		user.setLogin("test");
		user.setPassword("test");
		user.kontoPien =  new KontoPieniadze();
		user.kontoPien.setStanKonta(300);
		Intent addEvent = new Intent();
	    addEvent.setClassName("com.NCTW", "com.NCTW.CalendarActivity");
	    addEvent.putExtra("user_data", user);
	    setActivityIntent(addEvent);
	    mActivity = this.getActivity();


		tv1 = (TextView) mActivity.findViewById(com.NCTW.R.id.textWys);
		but = (Button) mActivity.findViewById(com.NCTW.R.id.buttonWys);
		signal = new CountDownLatch(1);
	}
	@UiThreadTest
	public void testBDText(){
		but.performClick();
		 try {
				signal.await(5, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 assertNotNull(tv1.getText().toString());
		 
	}
	
	
}
