
package com.NCTW.test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import android.content.Intent;
import android.test.ActivityInstrumentationTestCase2;
import android.test.UiThreadTest;
import android.widget.Button;
import android.widget.Spinner;

import com.NCTW.KontoPieniadze;
import com.NCTW.StatisticActivity;
import com.NCTW.User;

public class TestStat extends ActivityInstrumentationTestCase2<StatisticActivity>{
	
	public TestStat(){
		super("com.NCTW",StatisticActivity.class);
	}
	
	StatisticActivity mActivity;
	User user;
	CountDownLatch signal;
	Spinner s1, s2;
	Button bw, bg;

	

	
	protected void setUp() throws Exception{
		super.setUp();
		
		user = new User();
		user.setLogin("test");
		user.setPassword("test");
		user.kontoPien =  new KontoPieniadze();
		user.kontoPien.setStanKonta(300);
		user.kontoPien.setSuma_przychody(600);
		user.kontoPien.setSuma_wydatki(300);
		Intent addEvent = new Intent();
	    addEvent.setClassName("com.NCTW", "com.NCTW.StatisticActivity");
	    addEvent.putExtra("user_data", user);
	    setActivityIntent(addEvent);
	    mActivity = this.getActivity();
	    s1 = (Spinner) mActivity.findViewById(com.NCTW.R.id.spinner2);
	    s2 = (Spinner) mActivity.findViewById(com.NCTW.R.id.spinner3);
	    bw = (Button) mActivity.findViewById(com.NCTW.R.id.buttonWyd);
	    bg = (Button) mActivity.findViewById(com.NCTW.R.id.buttonWys);



	
		signal = new CountDownLatch(1);
	}

	public void testGraph(){
		mActivity.what = 0;
		 try {
				signal.await(10, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 assertNotNull(s1);
		 assertNotNull(s2);
		
		
		
		 try {
			 runTestOnUiThread(new Runnable() {
					public void run() {
						 s1.setSelection(2);
							s2.setSelection(5);
						bg.performClick();       
			        }
			    });
				signal.await(5, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 assertNotNull(mActivity.graphView);
	}

	public void testWys(){
		
		mActivity.what = 0;
		 try {
				signal.await(10, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 assertNotNull(s1);
		 assertNotNull(s2);
		
		
		
		 try {
			 runTestOnUiThread(new Runnable() {
					public void run() {
						 s1.setSelection(2);
							s2.setSelection(5);
						bw.performClick();       
			        }
			    });
				signal.await(5, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 assertNotNull(mActivity.findViewById(com.NCTW.R.id.textView1));
		
	}
}
