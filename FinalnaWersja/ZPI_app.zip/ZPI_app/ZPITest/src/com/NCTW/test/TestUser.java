package com.NCTW.test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import android.content.Intent;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.NCTW.KontoPieniadze;
import com.NCTW.MenuActivity;
import com.NCTW.User;
import com.NCTW.UserActivity;

public class TestUser  extends ActivityInstrumentationTestCase2<UserActivity>{
	
	public TestUser(){
		super("com.NCTW",UserActivity.class);
	}
	
	UserActivity mActivity;
	User user;
	CountDownLatch signal;
	TextView tv1, tv2, tv3;
	
	protected void setUp() throws Exception{
		super.setUp();
		
		user = new User();
		user.setLogin("test");
		user.setPassword("test");
		user.kontoPien =  new KontoPieniadze();
		user.kontoPien.setStanKonta(300);
		Intent addEvent = new Intent();
	    addEvent.setClassName("com.NCTW", "com.NCTW.UserActivity");
	    addEvent.putExtra("user_data", user);
	    setActivityIntent(addEvent);
	    mActivity = this.getActivity();


		tv1 = (TextView) mActivity.findViewById(com.NCTW.R.id.textLogin);
		tv2 = (TextView) mActivity.findViewById(com.NCTW.R.id.textMail);
		tv3 = (TextView) mActivity.findViewById(com.NCTW.R.id.textBilans);
		signal = new CountDownLatch(1);
	}
	
	public void testUser(){
		 assertNotNull(tv3);
		 try {
				signal.await(5, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 assertEquals(tv1.getText().toString(),"test");
		 assertEquals(tv2.getText().toString(),"test@test.pl");
	}
	

}
